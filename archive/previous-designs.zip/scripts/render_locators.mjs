import fs from "node:fs";
import path from "node:path";
import zlib from "node:zlib";

const root = "C:/Users/jeffg/dev/garden-auger-technic";
const outDir = path.join(root, "renders");
fs.mkdirSync(outDir, { recursive: true });

function loadStl(file) {
  const wrapped = JSON.parse(fs.readFileSync(file, "utf8"));
  const raw = Buffer.from(wrapped.bytes_base64, "base64");
  const count = raw.readUInt32LE(80);
  const tris = [];
  let offset = 84;
  for (let i = 0; i < count; i++) {
    const nums = [];
    for (let k = 0; k < 12; k++) nums.push(raw.readFloatLE(offset + 4 * k));
    tris.push([
      [nums[3], nums[4], nums[5]],
      [nums[6], nums[7], nums[8]],
      [nums[9], nums[10], nums[11]],
    ]);
    offset += 50;
  }
  return tris;
}

function normal(tri) {
  const [a, b, c] = tri;
  const nx = (b[1] - a[1]) * (c[2] - a[2]) - (b[2] - a[2]) * (c[1] - a[1]);
  const ny = (b[2] - a[2]) * (c[0] - a[0]) - (b[0] - a[0]) * (c[2] - a[2]);
  const nz = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
  const length = Math.hypot(nx, ny, nz) || 1;
  return [nx / length, ny / length, nz / length];
}

function shade(tri, rgb, light) {
  const n = normal(tri);
  const ndot = 0.38 + 0.62 * Math.max(0, n[0] * light[0] + n[1] * light[1] + n[2] * light[2]);
  return rgb.map((c) => Math.min(255, (c * ndot) | 0));
}

function render(meshes, eye, target, up, size, file, scale) {
  const [width, height] = size;
  let fx = target[0] - eye[0];
  let fy = target[1] - eye[1];
  let fz = target[2] - eye[2];
  const fl = Math.hypot(fx, fy, fz);
  fx /= fl;
  fy /= fl;
  fz /= fl;
  let rx = fy * up[2] - fz * up[1];
  let ry = fz * up[0] - fx * up[2];
  let rz = fx * up[1] - fy * up[0];
  const rl = Math.hypot(rx, ry, rz);
  rx /= rl;
  ry /= rl;
  rz /= rl;
  const ux = ry * fz - rz * fy;
  const uy = rz * fx - rx * fz;
  const uz = rx * fy - ry * fx;

  function project(p) {
    const dx = p[0] - eye[0];
    const dy = p[1] - eye[1];
    const dz = p[2] - eye[2];
    const z = dx * fx + dy * fy + dz * fz;
    const x = dx * rx + dy * ry + dz * rz;
    const y = dx * ux + dy * uy + dz * uz;
    const s = scale / Math.max(z, 1);
    return [width / 2 + x * s, height / 2 - y * s, z];
  }

  const buf = Buffer.alloc(width * height * 3, 0);
  for (let i = 0; i < width * height; i++) {
    buf[i * 3] = 28;
    buf[i * 3 + 1] = 32;
    buf[i * 3 + 2] = 38;
  }
  const depth = new Float64Array(width * height);
  depth.fill(1e9);
  let light = [0.35, 0.25, 0.9];
  const ll = Math.hypot(...light);
  light = light.map((c) => c / ll);

  for (const [color, tris] of meshes) {
    for (const tri of tris) {
      const pts = tri.map(project);
      if (Math.min(...pts.map((p) => p[2])) < 1) continue;
      const rgb = shade(tri, color, light);
      const xs = pts.map((p) => p[0]);
      const ys = pts.map((p) => p[1]);
      const minx = Math.max(0, Math.floor(Math.min(...xs)));
      const maxx = Math.min(width - 1, Math.ceil(Math.max(...xs)));
      const miny = Math.max(0, Math.floor(Math.min(...ys)));
      const maxy = Math.min(height - 1, Math.ceil(Math.max(...ys)));
      if (minx > maxx || miny > maxy) continue;
      const [p0, p1, p2] = pts;
      const denom = (p1[1] - p2[1]) * (p0[0] - p2[0]) + (p2[0] - p1[0]) * (p0[1] - p2[1]);
      if (Math.abs(denom) < 1e-8) continue;
      for (let y = miny; y <= maxy; y++) {
        for (let x = minx; x <= maxx; x++) {
          const w0 = ((p1[1] - p2[1]) * (x - p2[0]) + (p2[0] - p1[0]) * (y - p2[1])) / denom;
          const w1 = ((p2[1] - p0[1]) * (x - p2[0]) + (p0[0] - p2[0]) * (y - p2[1])) / denom;
          const w2 = 1 - w0 - w1;
          if (w0 < -0.001 || w1 < -0.001 || w2 < -0.001) continue;
          const z = w0 * p0[2] + w1 * p1[2] + w2 * p2[2];
          const idx = y * width + x;
          if (z < depth[idx]) {
            depth[idx] = z;
            buf[idx * 3] = rgb[0];
            buf[idx * 3 + 1] = rgb[1];
            buf[idx * 3 + 2] = rgb[2];
          }
        }
      }
    }
  }

  const rows = [];
  for (let y = 0; y < height; y++) {
    rows.push(Buffer.concat([Buffer.from([0]), buf.subarray(y * width * 3, (y + 1) * width * 3)]));
  }
  const raw = Buffer.concat(rows);
  function chunk(tag, data) {
    const body = Buffer.concat([tag, data]);
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length);
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(zlib.crc32(body) >>> 0);
    return Buffer.concat([len, body, crc]);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 2;
  const png = Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk(Buffer.from("IHDR"), ihdr),
    chunk(Buffer.from("IDAT"), zlib.deflateSync(raw, { level: 6 })),
    chunk(Buffer.from("IEND"), Buffer.alloc(0)),
  ]);
  fs.writeFileSync(file, png);
  console.log(file, png.length);
}

function renderOrtho(meshes, from, up, size, file) {
  let fx = from[0];
  let fy = from[1];
  let fz = from[2];
  const fl = Math.hypot(fx, fy, fz) || 1;
  fx /= fl;
  fy /= fl;
  fz /= fl;
  const vx = -fx;
  const vy = -fy;
  const vz = -fz;
  let rx = vy * up[2] - vz * up[1];
  let ry = vz * up[0] - vx * up[2];
  let rz = vx * up[1] - vy * up[0];
  const rl = Math.hypot(rx, ry, rz) || 1;
  rx /= rl;
  ry /= rl;
  rz /= rl;
  const ux = ry * vz - rz * vy;
  const uy = rz * vx - rx * vz;
  const uz = rx * vy - ry * vx;
  const cam = (p) => [p[0] * rx + p[1] * ry + p[2] * rz, p[0] * ux + p[1] * uy + p[2] * uz, p[0] * vx + p[1] * vy + p[2] * vz];

  let minx = 1e9;
  let maxx = -1e9;
  let miny = 1e9;
  let maxy = -1e9;
  for (const [, tris] of meshes) {
    for (const tri of tris) {
      for (const p of tri) {
        const c = cam(p);
        minx = Math.min(minx, c[0]);
        maxx = Math.max(maxx, c[0]);
        miny = Math.min(miny, c[1]);
        maxy = Math.max(maxy, c[1]);
      }
    }
  }
  const [width, height] = size;
  const s = Math.min((width * 0.84) / Math.max(maxx - minx, 1), (height * 0.84) / Math.max(maxy - miny, 1));
  const cx = (minx + maxx) / 2;
  const cy = (miny + maxy) / 2;
  const project = (p) => {
    const c = cam(p);
    return [width / 2 + (c[0] - cx) * s, height / 2 - (c[1] - cy) * s, c[2]];
  };

  const buf = Buffer.alloc(width * height * 3);
  for (let i = 0; i < width * height; i++) {
    buf[i * 3] = 28;
    buf[i * 3 + 1] = 32;
    buf[i * 3 + 2] = 38;
  }
  const depth = new Float64Array(width * height);
  depth.fill(1e9);
  let light = [0.35, -0.15, 0.85];
  const ll = Math.hypot(...light);
  light = light.map((c) => c / ll);

  for (const [color, tris] of meshes) {
    for (const tri of tris) {
      const n = normal(tri);
      if (n[0] * fx + n[1] * fy + n[2] * fz < 0.02) continue;
      const pts = tri.map(project);
      const rgb = shade(tri, color, light);
      const xs = pts.map((p) => p[0]);
      const ys = pts.map((p) => p[1]);
      const minpx = Math.max(0, Math.floor(Math.min(...xs)));
      const maxpx = Math.min(width - 1, Math.ceil(Math.max(...xs)));
      const minpy = Math.max(0, Math.floor(Math.min(...ys)));
      const maxpy = Math.min(height - 1, Math.ceil(Math.max(...ys)));
      if (minpx > maxpx || minpy > maxpy) continue;
      const [p0, p1, p2] = pts;
      const denom = (p1[1] - p2[1]) * (p0[0] - p2[0]) + (p2[0] - p1[0]) * (p0[1] - p2[1]);
      if (Math.abs(denom) < 1e-8) continue;
      for (let y = minpy; y <= maxpy; y++) {
        for (let x = minpx; x <= maxpx; x++) {
          const w0 = ((p1[1] - p2[1]) * (x - p2[0]) + (p2[0] - p1[0]) * (y - p2[1])) / denom;
          const w1 = ((p2[1] - p0[1]) * (x - p2[0]) + (p0[0] - p2[0]) * (y - p2[1])) / denom;
          const w2 = 1 - w0 - w1;
          if (w0 < -0.001 || w1 < -0.001 || w2 < -0.001) continue;
          const z = w0 * p0[2] + w1 * p1[2] + w2 * p2[2];
          const idx = y * width + x;
          if (z < depth[idx]) {
            depth[idx] = z;
            buf[idx * 3] = rgb[0];
            buf[idx * 3 + 1] = rgb[1];
            buf[idx * 3 + 2] = rgb[2];
          }
        }
      }
    }
  }

  const rows = [];
  for (let y = 0; y < height; y++) {
    rows.push(Buffer.concat([Buffer.from([0]), buf.subarray(y * width * 3, (y + 1) * width * 3)]));
  }
  const raw = Buffer.concat(rows);
  function chunk(tag, data) {
    const body = Buffer.concat([tag, data]);
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length);
    const crc = Buffer.alloc(4);
    crc.writeUInt32BE(zlib.crc32(body) >>> 0);
    return Buffer.concat([len, body, crc]);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 2;
  const png = Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk(Buffer.from("IHDR"), ihdr),
    chunk(Buffer.from("IDAT"), zlib.deflateSync(raw, { level: 6 })),
    chunk(Buffer.from("IEND"), Buffer.alloc(0)),
  ]);
  fs.writeFileSync(file, png);
  console.log(file, png.length);
}

const upper = loadStl(process.argv[2]);
const lower = loadStl(process.argv[3]);
const upperColor = [214, 168, 92];
const lowerColor = [92, 168, 154];
console.log("tris", upper.length, lower.length);
const lifted = upper.map((tri) => tri.map((p) => [p[0], p[1], p[2] + 36]));

renderOrtho(
  [
    [upperColor, lifted],
    [lowerColor, lower],
  ],
  [1, -1.1, 0.72],
  [0, 0, 1],
  [1400, 900],
  path.join(outDir, "locator-iso.png"),
);
renderOrtho([[upperColor, upper]], [0.15, -0.2, -1], [0, 1, 0], [1400, 800], path.join(outDir, "locator-upper-domes.png"));
renderOrtho([[lowerColor, lower]], [0.15, -0.35, 1], [0, 1, 0], [1400, 800], path.join(outDir, "locator-lower-dishes.png"));
renderOrtho(
  [
    [upperColor, upper],
    [lowerColor, lower],
  ],
  [0, -1, 0.08],
  [0, 0, 1],
  [1100, 900],
  path.join(outDir, "guard-front.png"),
);
