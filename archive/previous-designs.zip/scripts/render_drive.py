"""Render the live drive model to PNG. Stdlib only."""

from __future__ import annotations

import base64
import json
import math
import struct
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "renders"
AGENT = Path(r"C:\Users\jeffg\.cursor\projects\C-Users-jeffg-dev-garden-auger-technic\agent-tools")

CASE = AGENT / "f9225332-8548-4779-9b86-d14cb7f73688.txt"
HORN = AGENT / "d528146f-c796-4fab-b581-2d7ff2d3ae1b.txt"
HUB = AGENT / "36d5302f-ba94-4418-91cd-690f520b7487.txt"
HOUSING = AGENT / "5e1bc808-916a-4d5b-815a-377c44b62867.txt"

Q = 0.7071067811865476  # unused; pose is the +90 deg X rotation below
FLANGE_Y = 122.7


def load_stl(path: Path) -> list[tuple[tuple[float, float, float], ...]]:
    raw = base64.b64decode(json.loads(path.read_text(encoding="utf-8"))["bytes_base64"])
    count = struct.unpack_from("<I", raw, 80)[0]
    tris = []
    offset = 84
    for _ in range(count):
        nums = struct.unpack_from("<12fH", raw, offset)
        verts = tuple((nums[i], nums[i + 1], nums[i + 2]) for i in (3, 6, 9))
        tris.append(verts)
        offset += 50
    return tris


def pose_servo(p):
    x, y, z = p
    # +90 deg about X: local +Z (out of the horn) maps to world -Y.
    return (x, -z + FLANGE_Y, y)


def ring(y0, y1, outer_r, inner_r, n=48):
    tris = []
    for i in range(n):
        a0 = 2 * math.pi * i / n
        a1 = 2 * math.pi * (i + 1) / n
        c0, s0 = math.cos(a0), math.sin(a0)
        c1, s1 = math.cos(a1), math.sin(a1)
        o0 = (outer_r * c0, y0, outer_r * s0)
        o1 = (outer_r * c1, y0, outer_r * s1)
        o2 = (outer_r * c0, y1, outer_r * s0)
        o3 = (outer_r * c1, y1, outer_r * s1)
        i0 = (inner_r * c0, y0, inner_r * s0)
        i1 = (inner_r * c1, y0, inner_r * s1)
        i2 = (inner_r * c0, y1, inner_r * s0)
        i3 = (inner_r * c1, y1, inner_r * s1)
        tris += [
            (o0, o1, o3),
            (o0, o3, o2),
            (i1, i0, i2),
            (i1, i2, i3),
            (o2, o3, i3),
            (o2, i3, i2),
            (o1, o0, i0),
            (o1, i0, i1),
        ]
    return tris


def normal(tri):
    (x0, y0, z0), (x1, y1, z1), (x2, y2, z2) = tri
    nx = (y1 - y0) * (z2 - z0) - (z1 - z0) * (y2 - y0)
    ny = (z1 - z0) * (x2 - x0) - (x1 - x0) * (z2 - z0)
    nz = (x1 - x0) * (y2 - y0) - (y1 - y0) * (x2 - x0)
    length = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
    return (nx / length, ny / length, nz / length)


def shade(tri, rgb, light):
    n = normal(tri)
    ndot = 0.42 + 0.58 * max(0.0, n[0] * light[0] + n[1] * light[1] + n[2] * light[2])
    return tuple(min(255, int(c * ndot)) for c in rgb)


def render(meshes, eye, target, up, size, path: Path, scale=900.0):
    width, height = size
    fx = target[0] - eye[0]
    fy = target[1] - eye[1]
    fz = target[2] - eye[2]
    fl = math.sqrt(fx * fx + fy * fy + fz * fz)
    fx, fy, fz = fx / fl, fy / fl, fz / fl
    rx = fy * up[2] - fz * up[1]
    ry = fz * up[0] - fx * up[2]
    rz = fx * up[1] - fy * up[0]
    rl = math.sqrt(rx * rx + ry * ry + rz * rz)
    rx, ry, rz = rx / rl, ry / rl, rz / rl
    ux = ry * fz - rz * fy
    uy = rz * fx - rx * fz
    uz = rx * fy - ry * fx

    def project(p):
        dx, dy, dz = p[0] - eye[0], p[1] - eye[1], p[2] - eye[2]
        z = dx * fx + dy * fy + dz * fz
        x = dx * rx + dy * ry + dz * rz
        y = dx * ux + dy * uy + dz * uz
        s = scale / max(z, 1.0)
        return (width / 2 + x * s, height / 2 - y * s, z)

    buf = bytearray([24, 28, 34]) * (width * height)
    depth = [1e9] * (width * height)
    light = (0.45, 0.55, 0.7)
    ll = math.sqrt(sum(c * c for c in light))
    light = tuple(c / ll for c in light)

    for color, tris in meshes:
        for tri in tris:
            pts = [project(v) for v in tri]
            if min(p[2] for p in pts) < 1:
                continue
            rgb = shade(tri, color, light)
            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            minx = max(0, int(min(xs)))
            maxx = min(width - 1, int(max(xs)) + 1)
            miny = max(0, int(min(ys)))
            maxy = min(height - 1, int(max(ys)) + 1)
            if minx > maxx or miny > maxy:
                continue
            (x0, y0, z0), (x1, y1, z1), (x2, y2, z2) = pts
            denom = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2)
            if abs(denom) < 1e-8:
                continue
            for y in range(miny, maxy + 1):
                for x in range(minx, maxx + 1):
                    w0 = ((y1 - y2) * (x - x2) + (x2 - x1) * (y - y2)) / denom
                    w1 = ((y2 - y0) * (x - x2) + (x0 - x2) * (y - y2)) / denom
                    w2 = 1 - w0 - w1
                    if w0 < -0.001 or w1 < -0.001 or w2 < -0.001:
                        continue
                    z = w0 * z0 + w1 * z1 + w2 * z2
                    idx = y * width + x
                    if z < depth[idx]:
                        depth[idx] = z
                        o = idx * 3
                        buf[o : o + 3] = bytes(rgb)

    raw = b"".join(b"\x00" + bytes(buf[y * width * 3 : (y + 1) * width * 3]) for y in range(height))

    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    png = b"\x89PNG\r\n\x1a\n"
    png += chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
    png += chunk(b"IDAT", zlib.compress(raw, 6))
    png += chunk(b"IEND", b"")
    path.write_bytes(png)
    print(path, path.stat().st_size)


def main():
    case = [pose_servo(v) for tri in load_stl(CASE) for v in tri]
    case = [tuple(case[i : i + 3]) for i in range(0, len(case), 3)]
    horn = [pose_servo(v) for tri in load_stl(HORN) for v in tri]
    horn = [tuple(horn[i : i + 3]) for i in range(0, len(horn), 3)]
    hub = load_stl(HUB)
    bearing = ring(111.55, 118.55, 11.0, 4.0)
    housing = load_stl(HOUSING) if HOUSING.exists() else []
    print("tris", len(case), len(horn), len(hub), len(bearing), len(housing))

    meshes = [
        ((70, 96, 120), case),
        ((196, 198, 204), horn),
        ((214, 132, 62), hub),
        ((168, 176, 186), bearing),
        ((232, 196, 92), housing),
    ]
    OUT.mkdir(exist_ok=True)
    # Look at the flange from the side and slightly above.
    render(
        meshes,
        eye=(78, 168, 52),
        target=(0, 128, 0),
        up=(0, 0, 1),
        size=(1200, 800),
        path=OUT / "drive-iso.png",
    )
    render(
        meshes,
        eye=(36, 108, 22),
        target=(0, 118, 0),
        up=(0, 0, 1),
        size=(1200, 800),
        path=OUT / "drive-flange.png",
    )
    render(
        meshes,
        eye=(170, 90, 80),
        target=(0, 150, 0),
        up=(0, 0, 1),
        size=(1200, 800),
        path=OUT / "handheld-iso.png",
    )
    render(
        meshes,
        eye=(0, 40, 55),
        target=(0, 155, 8),
        up=(0, 0, 1),
        size=(1200, 800),
        path=OUT / "handheld-front.png",
    )


if __name__ == "__main__":
    main()
