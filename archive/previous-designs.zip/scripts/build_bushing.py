"""Rebuild the auger with a slide-on PLA sleeve and PETG structural parts.

Uses the installed noBS CAD kernel through its documented stdio operations.
The previous editable project is retained as the construction baseline.
"""

from __future__ import annotations

import base64
import json
import math
from pathlib import Path
import shutil
import zipfile

from cad_client import CadClient

ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / 'source/garden-auger-608-baseline.nbcad'
PROJECT = ROOT / 'garden-auger-drive.nbcad'
JOURNAL_D = 16.0
BUSHING_BORE_D = 16.4
BUSHING_OD = 22.0
FLANGE_D = 28.0
HORN_FACE_Y = 140.3
CLIP_GROOVE_D = 15.2
CLIP_GROOVE_START = 129.45
CLIP_GROOVE_END = 130.55


def profile(sketch: dict, points: list[tuple[float, float]], arcs: dict | None = None):
    """Replace a closed sketch loop, retaining its editable native feature."""
    arcs = arcs or {}
    entities = [[i + 1, {'type': 'point', 'position': {'x': x, 'y': y}}]
                for i, (x, y) in enumerate(points)]
    n = len(points)
    for i in range(n):
        entity = {'type': 'line', 'start': i + 1, 'end': (i + 1) % n + 1}
        if i in arcs:
            center, radius, start, end = arcs[i]
            entity = {'type': 'arc', 'center': {'x': center[0], 'y': center[1]},
                      'radius': radius, 'start_angle': start, 'end_angle': end}
        entities.append([n + i + 1, entity])
    snap = sketch['snapshot']
    snap.update(entities=entities, constraints=[], generated_points=[], fix_targets={},
                dim_params={}, dim_placements={}, dim_modes={}, next_entity=2*n,
                next_constraint=0)
    sketch['entity_id_high_water'] = 2*n
    sketch['profile_identities'] = {'next': 0, 'records': []}


def prepare_baseline():
    if not BASELINE.exists():
        shutil.copy2(PROJECT, BASELINE)
    with zipfile.ZipFile(BASELINE) as z:
        model = json.loads(z.read('model.json'))
    sketches = {s['name']: s for s in model['sketches']}
    journal_r=JOURNAL_D/2
    # A continuous 16 mm rear end lets the complete sleeve slide on before
    # installing a purchased 16 mm shaft retaining ring. Only the front
    # thrust shoulder is integral; the shallow groove is ahead of the socket.
    profile(sketches['Sketch84'], [
        (-1, 0), (-1, 2), (12, 7), (90, 10), (105, 10), (111.5, 10),
        (111.5, journal_r+.6), (112.1, journal_r),
        (CLIP_GROOVE_START, journal_r),
        (CLIP_GROOVE_START, CLIP_GROOVE_D/2),
        (CLIP_GROOVE_END, CLIP_GROOVE_D/2),
        (CLIP_GROOVE_END, journal_r),
        (139, journal_r), (139.5, journal_r-.5), (139.5, 0),
    ], {
        6: ((112.1, journal_r+.6), .6, math.pi, 1.5*math.pi),
    })
    # Remove obsolete purchased bearings, retainer, round horn, seat cuts,
    # and face-based holes whose saved references belong to an earlier horn.
    suppressed = {13, 15, 35, 38, 112, 117, 122, 221, 223,
                  213, 216, 219, 298, 294, 295}
    for f in model['document']['history']['features']:
        if f['id'] in suppressed:
            f['suppressed'] = True
    # Clear the flight through the guard up to its actual end (Y=110).
    # A smaller front opening then supports the bushing's forward flange.
    cut = next(e for e in model['extrudes'] if e['feature_id'] == 89)
    cut['extent'] = {'type': 'two_sides', 'distance': 4.2, 'second_distance': 2.7}
    # Move the servo cavity and ears to match the corrected horn stack.
    # The outer shell already extends beyond the new cavity; grip is retained.
    pocket_shift = 12.8
    for name in ['Sketch45', 'Sketch62']:
        sketches[name]['basis']['origin'][1] += pocket_shift
        datum = sketches[name]['plane']['datum_id']
        p = next(p for p in model['datum_planes'] if p['datum_id'] == datum)
        p['source']['distance'] -= pocket_shift
        p['basis']['origin'][1] += pocket_shift
    for name in ['Sketch80', 'Sketch81', 'Sketch95']:
        s = sketches[name]
        for _, e in s['snapshot']['entities']:
            if e['type'] == 'point':
                e['position']['y'] += pocket_shift
        s['profile_identities'] = {'next': 0, 'records': []}
    for name in ['Sketch54', 'Sketch55', 'Sketch56']:
        s = sketches[name]
        for _, e in s['snapshot']['entities']:
            if e['type'] == 'circle' and e['center']['y'] == 177:
                e['center']['y'] = 189.8
            if e['type'] == 'point' and e['position']['y'] == 177:
                e['position']['y'] = 189.8
        s['profile_identities'] = {'next': 0, 'records': []}
    # Rear screw access must reach the shell's real Z=24 top face. Retain
    # the original head seating height so the M3x18 screws still engage.
    moved_datums=set()
    for name in ['Sketch54','Sketch55']:
        s=sketches[name]
        s['basis']['origin'][2]=24
        datum=s['plane']['datum_id']
        if datum not in moved_datums:
            p=next(p for p in model['datum_planes'] if p['datum_id']==datum)
            p['source']['distance']=24;p['basis']['origin'][2]=24
            moved_datums.add(datum)
    next(e for e in model['extrudes'] if e['feature_id']==157)['extent']['distance']=24
    next(e for e in model['extrudes'] if e['feature_id']==159)['extent']['distance']=11.3
    assembly = model['assembly']['component_structure']
    # Drop stale automatic components and components for removed hardware.
    assembly['definitions'] = [d for d in assembly['definitions'] if d['id'] in {3, 6, 7, 8, 14}]
    assembly['occurrences'] = [o for o in assembly['occurrences'] if o['component_id'] in {3, 6, 7, 8, 14}]
    for d in assembly['definitions']:
        if d['id'] == 3:
            d['body_ids'] = [1]
        if d['id'] == 14:
            d['name'] = 'Square servo horn'
    for o in assembly['occurrences']:
        if o['component_id'] == 3:
            o['local_pose']['translation'] = [0, HORN_FACE_Y + 1, 0]
        if o['component_id'] == 14:
            o['name'] = 'Square servo horn'
    model['document']['name'] = 'Garden auger - slide-on PLA sleeve and PETG parts'
    return model


class Builder:
    def __init__(self, client):
        self.client = client

    def call(self, operation_name, **arguments):
        return self.client.call(operation_name, arguments)

    def poly(self, name, points, plane='yz'):
        self.call('sketch_begin', name=name, plane={'type':'origin_plane', 'plane':plane})
        self.call('sketch_set_grid_snap', enabled=False)
        for p, q in zip(points, points[1:] + points[:1]):
            self.client.call('sketch_add_line', {'from':{'x':p[0],'y':p[1]}, 'to_raw':{'x':q[0],'y':q[1]},'ctrl_held':True})
        self.call('sketch_finish')

    def revolve(self, name, points, operation, targets):
        previous_ids = {b['id'] for b in self.call('solid_scene')['bodies']}
        self.poly(name, points)
        r = self.call('solid_revolve', sketch_name=name, profile_indices=[0],
            axis_origin={'x':0,'y':0}, axis_direction={'x':1,'y':0}, angle_deg=360,
            flip=False, operation=operation, target_body_ids=targets)
        scene = self.call('solid_scene')
        assert not scene['errors'], scene['errors']
        if operation == 'new_body':
            created = [b['id'] for b in scene['bodies'] if b['id'] not in previous_ids]
            assert len(created) == 1, (created, r['document']['features'][-3:])
            r['created_body_id'] = created[0]
        print(name, 'OK', flush=True)
        return r

    def box(self, name, bounds, operation, targets):
        previous_ids = {b['id'] for b in self.call('solid_scene')['bodies']}
        x0,y0,x1,y1,z0,z1 = bounds
        self.call('sketch_begin', name=name, plane={'type':'origin_plane','plane':'xy'})
        self.call('sketch_set_grid_snap', enabled=False)
        self.call('sketch_add_rectangle_locked', mode='two_point',
            anchor={'x':x0,'y':y0},corner_hint={'x':x1,'y':y1},
            width_mm=x1-x0,height_mm=y1-y0,ctrl_held=True)
        self.call('sketch_finish')
        # A box whose lower face is above/below the sketch plane uses a native
        # extrude plus move, so all manufacturing geometry remains editable.
        r = self.call('solid_extrude', sketch_name=name, profile_indices=[0],
            operation='new_body', extent={'type':'distance','distance':z1-z0},
            taper_angle_deg=0,flip=False,target_body_ids=[])
        scene = self.call('solid_scene')
        body = next(b['id'] for b in scene['bodies'] if b['id'] not in previous_ids)
        if z0:
            self.call('solid_move_copy',body_ids=[body],translation={'x':0,'y':0,'z':z0},
                pivot={'x':0,'y':0,'z':0},copy=False)
        for target in targets:
            self.call('solid_combine',target_body_id=target,tool_body_ids=[body],
                operation=operation,keep_tools=target!=targets[-1])
        print(name, 'OK', flush=True)

    def prism(self,name,points,z0,z1,target):
        previous_ids={b['id'] for b in self.call('solid_scene')['bodies']}
        self.poly(name,points,plane='xy')
        self.call('solid_extrude',sketch_name=name,profile_indices=[0],operation='new_body',
            extent={'type':'distance','distance':z1-z0},taper_angle_deg=0,flip=False,target_body_ids=[])
        tool=next(b['id'] for b in self.call('solid_scene')['bodies'] if b['id'] not in previous_ids)
        self.call('solid_move_copy',body_ids=[tool],translation={'x':0,'y':0,'z':z0},
            pivot={'x':0,'y':0,'z':0},copy=False)
        self.call('solid_combine',target_body_id=target,tool_body_ids=[tool],operation='join',keep_tools=False)
        print(name,'OK',flush=True)


def save_project(client, target):
    result = client.call('cad_project_model')
    raw = result if isinstance(result,str) else json.dumps(result)
    model = json.loads(raw)
    if 'model_json' in model:
        raw = model['model_json']
        model = json.loads(raw)
    with zipfile.ZipFile(BASELINE) as z:
        manifest = json.loads(z.read('manifest.json'))
    manifest['model_schema_version'] = model['schema_version']
    manifest['saved_at'] = __import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('manifest.json', json.dumps(manifest))
        z.writestr('model.json', raw)
    return model


def main():
    model = prepare_baseline()
    (ROOT/'scripts/_bushing-prepared.json').write_text(json.dumps(model), encoding='utf-8')
    with CadClient() as client:
        client.call('cad_load_project_model', {'model_json':json.dumps(model)})
        print('Prepared baseline loaded', flush=True)
        b = Builder(client)
        bore_r=BUSHING_BORE_D/2
        sleeve_r=BUSHING_OD/2
        flange_r=FLANGE_D/2
        b.call('solid_move_copy',body_ids=[216],translation={'x':0,'y':.8,'z':0},
            pivot={'x':0,'y':0,'z':0},copy=False)
        # Keep the imported flight and editable revolved core in one print
        # component. This engine's exact fuse drops geometry on this imported
        # flight; pack_bushing_prints.py performs a verified mesh union instead.
        # Continuous stepped cavity, including both thrust stops.
        b.revolve('Full sleeve housing seat', [
            (110.9,0),(110.9,10.6),(111.6,10.6),(111.6,flange_r+.2),
            (113.9,flange_r+.2),(116.9,sleeve_r+.2),(127.1,sleeve_r+.2),(127.1,flange_r+.2),
            (129.3,flange_r+.2),(129.3,12.6),(144.3,12.6),(144.3,0),
        ], 'cut', [26,46])
        # One closed sleeve, printed upright. The front mouth clears the
        # root fillet; the small rear chamfer leaves a broad clip thrust face.
        r = b.revolve('One-piece slide-on PLA sleeve', [
            (111.8,bore_r+.8),(112.6,bore_r),(129,bore_r),(129.2,bore_r+.2),
            (129.2,flange_r),(127.2,flange_r),(127.2,sleeve_r),(116.8,sleeve_r),
            (113.8,flange_r),(111.8,flange_r),
        ], 'new_body', [])
        sleeve = r['created_body_id']
        b.prism('Sleeve 45-degree print-friendly key',[(10.4,119),(14.5,119),(14.5,122),(10.4,126.1)],-2.5,2.5,sleeve)
        b.box('Bushing antirotation seat',(10.2,118.8,14.9,126.3,-2.9,2.9),'cut',[26,46])
        # Installed-envelope reference only. This purchased spring-steel
        # clip is excluded from all print exports. DIN 471 size-16 groove:
        # diameter 15.2, width 1.1; nominal clip thickness 1 mm.
        clip = b.revolve('Purchased 16 mm retaining clip reference', [
            (129.5,7.6),(130.5,7.6),(130.5,9.8),(129.5,9.8),
        ], 'new_body', [])['created_body_id']
        b.box('Clip opening',(-1.6,129.4,1.6,130.6,0,13),'cut',[clip])
        b.box('Clip right lug envelope',(1.6,129.5,4,130.5,7.8,10.5),'join',[clip])
        b.box('Clip left lug envelope',(-4,129.5,-1.6,130.5,7.8,10.5),'join',[clip])
        # Replace stale face-bound horn holes with axial, editable cuts.
        b.revolve('Horn center screw clearance',[(132.9,0),(132.9,1.7),(143.4,1.7),(143.4,0)],'cut',[216])
        b.revolve('Horn screw counterbore',[(133.1,0),(133.1,3),(135.7,3),(135.7,0)],'cut',[216])
        b.revolve('Horn spline pocket',[(141.5,0),(141.5,2.85),(143.3,2.85),(143.3,0)],'cut',[216])
        b.call('assembly_update_component',component={'id':8,'body_ids':[90,15],'name':'One-piece printed auger'})
        for body,name in [(sleeve,'One-piece PLA wear sleeve'),(clip,'Purchased 16 mm retaining clip')]:
            b.call('assembly_create_component',name=name,body_ids=[body],absorb_promoted_bodies=True)
        (ROOT/'scripts/_bushing-parts.json').write_text(json.dumps({'sleeve':sleeve,'clip':clip}),encoding='utf-8')
        finish(client,sleeve,clip)


def finish(client,sleeve,clip):
    b=Builder(client)
    colors = [(1,(75,98,119),'Purchased servo reference'),
              (26,(229,174,60),'PETG'),
              (46,(229,174,60),'PETG'),
              (90,(213,126,55),'PETG'),
              (15,(213,126,55),'PETG'),
              (216,(190,195,202),'PETG'),
              (sleeve,(55,170,161),'PLA - replaceable wear sleeve'),
              (clip,(150,166,189),'Purchased spring-steel clip - do not print')]
    for body,color,name in colors:
        b.call('set_body_appearance',body_id=body,color={**dict(zip(('r','g','b'),color)),'a':255},material_name=name)
    scene = b.call('solid_scene')
    assert not scene['errors'], scene['errors']
    print('Bodies:',[(x['id'],x['name']) for x in scene['bodies']],flush=True)
    (ROOT/'scripts/_bushing-scene.json').write_text(json.dumps(scene),encoding='utf-8')
    report = b.call('assembly_interference_check',clearance_threshold_mm=.1)
    assert not any(p['interfering'] for p in report['pairs']
                   if {p['body_a'],p['body_b']} != {15,90}), report
    (ROOT/'scripts/_bushing-interference.json').write_text(json.dumps(report),encoding='utf-8')
    print('Interference: zero overlap volumes',flush=True)
    model = save_project(client,ROOT/'garden-auger-bushing.nbcad')
    (ROOT/'scripts/_bushing-final.json').write_text(json.dumps(model),encoding='utf-8')
    exported = b.call('solid_export_3mf',body_ids=[26,46,15,90,216,sleeve],scope='definition',
        linear_deflection=.08,angular_deflection=.2,slicer_target='bambu_studio')
    (ROOT/'scripts/_bushing-raw.3mf').write_bytes(base64.b64decode(exported['bytes_base64']))
    preflight=b.call('solid_export_preflight')
    (ROOT/'scripts/_bushing-preflight.json').write_text(json.dumps(preflight),encoding='utf-8')
    print('Preflight',json.dumps(preflight)[:1600],flush=True)
    print('Saved bushing CAD and 3MF',flush=True)


if __name__ == '__main__':
    main()
