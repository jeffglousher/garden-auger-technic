"""Verify sleeve installation and end travel, then export the fit-check print."""

import base64
import json
import math
from pathlib import Path

from cad_client import CadClient
from build_bushing import Builder,save_project

ROOT=Path(__file__).resolve().parents[1]


def main():
    model=json.loads((ROOT/'scripts/_bushing-final.json').read_text())
    parts=json.loads((ROOT/'scripts/_bushing-parts.json').read_text())
    structure=model['assembly']['component_structure']
    auger=next(o['id'] for o in structure['occurrences'] if o['component_id']==8)
    def occurrence_for_body(body):
        component=next(d['id'] for d in structure['definitions'] if body in d['body_ids'])
        return next(o['id'] for o in structure['occurrences'] if o['component_id']==component)
    sleeve=occurrence_for_body(parts['sleeve'])
    clip=occurrence_for_body(parts['clip'])
    reports=[]
    with CadClient() as c:
        c.call('cad_load_project_model',{'model_json':json.dumps(model)})
        for label,shaft_y,bush_y,clip_y in [('centered',0,0,0),('push thrust',.4,.1,.4),('pull thrust',-.45,-.1,-.4)]:
            for occurrence,dy in [(auger,shaft_y),(sleeve,bush_y),(clip,clip_y)]:
                c.call('assembly_set_occurrence_pose',{'occurrence_id':occurrence,
                    'local_pose':{'translation':[0,dy,0],'rotation':[0,0,0,1]}})
            report=c.call('assembly_interference_check',{'clearance_threshold_mm':1.1})
            assert report['exact']
            assert not any(p['interfering'] for p in report['pairs'] if {p['body_a'],p['body_b']}!={15,90}),report
            reports.append({'position':label,'auger_shift_mm':shaft_y,'bushing_shift_mm':bush_y,
                            'clip_shift_mm':clip_y,
                            'exact':True,'unintended_overlap_volume_mm3':0,'pairs':report['pairs']})
            print(label,'no unintended overlap',flush=True)
        # Reopen the centered model for the final files and physical coupon.
        c.call('cad_load_project_model',{'model_json':json.dumps(model)})
        scene=c.call('solid_scene')
        assert len(scene['bodies'])==8 and not scene['errors']
        shaft=next(b for b in scene['bodies'] if b['id']==15)
        assert max(shaft['mesh']['positions'][1::3])>139.49
        vertices=shaft['mesh']['positions']
        tail=[vertices[k:k+3] for k in range(0,len(vertices),3) if vertices[k+1]>=112.1-1e-6]
        max_radius=max(math.hypot(p[0],p[2]) for p in tail)
        assert max_radius<=8.00001, max_radius
        save_project(c,ROOT/'garden-auger-drive.nbcad')
        slide_reports=[]
        for dy in [28,20,14,8,4,2,0]:
            c.call('assembly_set_occurrence_pose',{'occurrence_id':sleeve,
                'local_pose':{'translation':[0,dy,0],'rotation':[0,0,0,1]}})
            report=c.call('assembly_interference_check',{'clearance_threshold_mm':.1})
            assert report['exact']
            sleeve_pairs=[p for p in report['pairs'] if parts['sleeve'] in {p['body_a'],p['body_b']}
                          and bool({15,90}&{p['body_a'],p['body_b']})]
            assert not any(p['interfering'] for p in sleeve_pairs),sleeve_pairs
            slide_reports.append({'sleeve_shift_mm':dy,'exact':True,'auger_overlap_mm3':0})
        (ROOT/'scripts/_bushing-slide-check.json').write_text(json.dumps({
            'maximum_rear_shaft_radius_mm':max_radius,'minimum_sleeve_bore_radius_mm':8.2,
            'retaining_clip_installed_after_sleeve':True,'positions':slide_reports},indent=2))
        print('Full sleeve slides over the rear shaft: seven exact positions clear',flush=True)
        c.call('cad_load_project_model',{'model_json':json.dumps(model)})
        b=Builder(c)
        b.box('Crop fit-check housing',( -120,130.4,120,220,-35,35),'cut',[26,46])
        b.box('Crop journal coupon',(-35,-6,35,105,-35,35),'cut',[15])
        fit_model=c.call('cad_project_model')
        fit_model=json.loads(fit_model) if isinstance(fit_model,str) else fit_model
        fit_model['document']['name']='Garden auger - slide-on sleeve fit check'
        fit_model['visibility']['hidden_body_ids']=[1,90]
        definitions=fit_model['assembly']['component_structure']['definitions']
        next(d for d in definitions if d['id']==8)['body_ids']=[15]
        next(d for d in definitions if d['id']==8)['name']='Journal fit coupon'
        for o in fit_model['assembly']['component_structure']['occurrences']:
            if o['component_id']==3:o['visible']=False
        c.call('cad_load_project_model',{'model_json':json.dumps(fit_model)})
        save_project(c,ROOT/'garden-auger-fit-check.nbcad')
        scene=c.call('solid_scene');assert not scene['errors']
        export=c.call('solid_export_3mf',{'body_ids':[26,46,15,216,parts['sleeve']],
            'scope':'definition','linear_deflection':.08,'angular_deflection':.2,'slicer_target':'bambu_studio'})
        (ROOT/'scripts/_bushing-fit-raw.3mf').write_bytes(base64.b64decode(export['bytes_base64']))
    (ROOT/'scripts/_bushing-end-travel.json').write_text(json.dumps(reports,indent=2))
    print('Fit-check CAD and mesh exported',flush=True)


if __name__=='__main__':main()
