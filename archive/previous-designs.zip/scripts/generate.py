"""Emit the reusable Injora INJS035-360 servo script.

The .nbcad.jsonc file is the construction source for every site that uses
this servo. The garden auger itself lives in garden-auger-drive.nbcad.
"""

from __future__ import annotations

import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"

# INJS035 case drawing, same case as the INJS035-360. The output sits 10 mm
# from one end of the 40 mm case, so the case center is off the output axis.
CASE_X = 40.0
CASE_Y = 20.0
CASE_H = 37.5  # case bottom to case top
CASE_CX = -10.0  # case center on local X; the output is at X = 0
BOSS_D = 10.0  # output boss under the horn
BOSS_H = 2.0
EAR_W = 8.0  # each ear; 56 mm across both
EAR_T = 2.7
EAR_TOP = 24.7  # case bottom to the top face of the ears
EAR_SLOT_X = 24.5  # from the case center; slots 49 mm apart
EAR_SLOT_Y = 5.0  # slots 10 mm apart across the case
EAR_SLOT_W = 4.0
EAR_SLOT_REACH = 1.5  # notch runs this far past the slot center, open at the ear end

# Agreed round horn: 20 mm disc, four M3 holes on a 14 mm circle.
HORN_OD = 20.0
HORN_T = 2.0
HORN_BC = 14.0
HORN_HOLE_D = 3.2
HORN_SCREW_D = 3.4

def flatten(items: list) -> list:
    out = []
    for item in items:
        if isinstance(item, list):
            out.extend(flatten(item))
        else:
            out.append(item)
    return out


def step_call(step_id: str, group: str, operation: str, arguments: dict) -> dict:
    return {
        "id": step_id,
        "call": {"group": group, "operation": operation, "arguments": arguments},
    }


def note(text: str, chapter: str | None = None) -> dict:
    item = {"note": text, "duration_ms": 800}
    if chapter:
        item["chapter"] = chapter
    return item


def plane(step_id: str, name: str, axis: str, distance: float) -> list[dict]:
    return [
        step_call(
            step_id,
            "solid/reference",
            "construction_plane_offset",
            {
                "name": name,
                "distance": distance,
                "reference": {"type": "origin_plane", "plane": axis},
            },
        ),
        {
            "let": {
                f"{step_id}_ref": {
                    "type": "datum_plane",
                    "datum_id": {
                        "$select": {
                            "from": {"$ref": step_id},
                            "path": "/planes",
                            "take": "last",
                            "pointer": "/datum_id",
                        }
                    },
                }
            }
        },
    ]


def begin(step_id: str, name: str, plane_ref: str) -> list[dict]:
    return [
        step_call(
            step_id,
            "sketch/draw",
            "sketch_begin",
            {"name": name, "plane": {"$ref": plane_ref}},
        ),
        step_call(
            f"{step_id}_snap",
            "sketch/selection",
            "sketch_set_grid_snap",
            {"enabled": False},
        ),
    ]


def rect(step_id: str, x0: float, y0: float, x1: float, y1: float) -> dict:
    return step_call(
        step_id,
        "sketch/draw",
        "sketch_add_rectangle_locked",
        {
            "mode": "two_point",
            "anchor": {"x": x0, "y": y0},
            "corner_hint": {"x": x1, "y": y1},
            "width_mm": round(x1 - x0, 6),
            "height_mm": round(y1 - y0, 6),
            "ctrl_held": True,
        },
    )


def circle(step_id: str, cx: float, cy: float, diameter: float) -> dict:
    return step_call(
        step_id,
        "sketch/draw",
        "sketch_add_circle_locked",
        {
            "mode": "center_diameter",
            "anchor": {"x": cx, "y": cy},
            "edge_hint": {"x": cx + diameter / 2.0, "y": cy},
            "diameter_mm": diameter,
            "ctrl_held": True,
        },
    )


def finish(step_id: str) -> dict:
    return step_call(step_id, "sketch/draw", "sketch_finish", {})


def extrude(
    step_id: str,
    sketch: str,
    profiles: list[int],
    operation: str,
    distance: float,
    flip: bool,
    targets: list | None = None,
) -> dict:
    return step_call(
        step_id,
        "solid/build",
        "solid_extrude",
        {
            "sketch_name": sketch,
            "profile_indices": profiles,
            "operation": operation,
            "extent": {"type": "distance", "distance": distance},
            "taper_angle_deg": 0,
            "flip": flip,
            "target_body_ids": targets or [],
        },
    )


def bind_body(extrude_id: str, feature_name: str, body_name: str) -> list[dict]:
    return [
        {
            "let": {
                feature_name: {
                    "$select": {
                        "from": {"$ref": extrude_id},
                        "path": "/document/features",
                        "take": "last",
                        "pointer": "/id",
                    }
                }
            }
        },
        {
            "let": {
                body_name: {
                    "$select": {
                        "from": {"$ref": extrude_id},
                        "path": "/scene/bodies",
                        "where": {"/feature_id": {"$ref": feature_name}},
                        "take": "one",
                    }
                }
            }
        },
    ]


def body_id(name: str) -> dict:
    return {"$ref": name, "pointer": "/id"}


def bolt_circle() -> list[tuple[float, float]]:
    radius = HORN_BC / 2.0
    return [
        (radius * math.cos(math.radians(angle)), radius * math.sin(math.radians(angle)))
        for angle in (45, 135, 225, 315)
    ]


def servo_steps() -> list[dict]:
    half_y = CASE_Y / 2.0
    x0 = CASE_CX - CASE_X / 2.0
    x1 = CASE_CX + CASE_X / 2.0
    bottom = -(CASE_H + BOSS_H + HORN_T)
    case_top = -(BOSS_H + HORN_T)
    horn_back = -HORN_T
    ear_bottom = bottom + EAR_TOP - EAR_T
    steps: list[dict] = [
        note(
            "INJS035-360 continuous servo. Origin is the center of the round-horn "
            "mating face. +Z points out of that face, toward the load. The case "
            "is in negative Z, +X is the 40 mm length, and +Y is the 20 mm width. "
            "The output is 10 mm from the +X end of the case. "
            "Place another site with a new occurrence of component INJS035-360.",
            "Injora servo",
        ),
        step_call(
            "servo_name",
            "document/files",
            "cad_set_document_name",
            {"name": "INJS035-360"},
        ),
    ]
    steps += plane("servo_bottom_plane", "servo case bottom", "xy", bottom)
    steps += [
        begin("servo_case_sketch", "servo case", "servo_bottom_plane_ref"),
        rect("servo_case_rect", x0, -half_y, x1, half_y),
        finish("servo_case_finish"),
        extrude("servo_case_extrude", "servo case", [0], "new_body", CASE_H, False),
    ]
    steps += bind_body("servo_case_extrude", "servo_case_feature", "servo_case_body")
    steps += plane("servo_ear_plane", "servo ears", "xy", ear_bottom)
    steps += [
        begin("servo_ears_sketch", "servo ears", "servo_ear_plane_ref"),
        rect("servo_ear_neg", x0 - EAR_W, -half_y, x0, half_y),
        rect("servo_ear_pos", x1, -half_y, x1 + EAR_W, half_y),
        finish("servo_ears_finish"),
        extrude(
            "servo_ears_extrude",
            "servo ears",
            [0, 1],
            "join",
            EAR_T,
            False,
            [body_id("servo_case_body")],
        ),
        begin("servo_ear_slots_sketch", "servo ear slots", "servo_ear_plane_ref"),
    ]
    half_w = EAR_SLOT_W / 2.0
    neg_x = CASE_CX - EAR_SLOT_X
    pos_x = CASE_CX + EAR_SLOT_X
    for index, sy in enumerate((EAR_SLOT_Y, -EAR_SLOT_Y)):
        steps.append(
            rect(f"servo_ear_slot_neg_{index}", x0 - EAR_W - 1.0, sy - half_w, neg_x + EAR_SLOT_REACH, sy + half_w)
        )
        steps.append(
            rect(f"servo_ear_slot_pos_{index}", pos_x - EAR_SLOT_REACH, sy - half_w, x1 + EAR_W + 1.0, sy + half_w)
        )
    steps += [
        finish("servo_ear_slots_finish"),
        extrude(
            "servo_ear_slots_cut",
            "servo ear slots",
            [0, 1, 2, 3],
            "cut",
            EAR_T,
            False,
            [body_id("servo_case_body")],
        ),
    ]
    steps += plane("servo_boss_plane", "servo case top", "xy", case_top)
    steps += [
        begin("servo_boss_sketch", "servo output boss", "servo_boss_plane_ref"),
        circle("servo_boss_circle", 0, 0, BOSS_D),
        finish("servo_boss_finish"),
        extrude(
            "servo_boss_extrude",
            "servo output boss",
            [0],
            "join",
            BOSS_H,
            False,
            [body_id("servo_case_body")],
        ),
    ]
    steps += plane("servo_horn_plane", "servo horn back", "xy", horn_back)
    steps += [
        begin("servo_horn_sketch", "servo horn", "servo_horn_plane_ref"),
        circle("servo_horn_circle", 0, 0, HORN_OD),
        finish("servo_horn_finish"),
        extrude("servo_horn_extrude", "servo horn", [0], "new_body", HORN_T, False),
    ]
    steps += bind_body("servo_horn_extrude", "servo_horn_feature", "servo_horn_body")
    steps += plane("servo_horn_face_plane", "servo horn face", "xy", 0)
    steps += [begin("servo_horn_holes_sketch", "servo horn holes", "servo_horn_face_plane_ref")]
    steps.append(circle("servo_horn_center", 0, 0, HORN_SCREW_D))
    for index, (sx, sy) in enumerate(bolt_circle()):
        steps.append(circle(f"servo_horn_hole_{index}", sx, sy, HORN_HOLE_D))
    steps += [
        finish("servo_horn_holes_finish"),
        extrude(
            "servo_horn_holes_cut",
            "servo horn holes",
            [0, 1, 2, 3, 4],
            "cut",
            HORN_T,
            True,
            [body_id("servo_horn_body")],
        ),
        step_call(
            "servo_component",
            "assembly/joints",
            "assembly_create_component",
            {
                "name": "INJS035-360",
                "body_ids": [body_id("servo_case_body"), body_id("servo_horn_body")],
                "absorb_promoted_bodies": True,
                "local_coordinate_system": {
                    "translation": [0, 0, 0],
                    "rotation": [0, 0, 0, 1],
                },
            },
        ),
    ]
    return flatten(steps)


def main() -> None:
    servo = {
        "version": 1,
        "name": "INJS035-360 continuous servo",
        "starting_state": "empty",
        "steps": servo_steps(),
        "exports": {"component": {"$ref": "servo_component"}},
    }
    body = json.dumps(servo, indent=2)
    # Insert header comments above the JSON.
    comment = """// INJS035-360 continuous-rotation servo.
// Reuse at each site: include this file, then place another occurrence of
// component INJS035-360. Copy this file into the other project's script
// folder. An include cannot climb out of that folder.
//
// Datum: origin at the center of the round-horn mating face.
// +Z points out of that face, toward the load.
// +X is the 40 mm case length. +Y is the 20 mm case width.
// The case lies in negative Z.
//
// From the INJS035 case drawing: case 40 x 20 x 37.5 mm, 41.5 mm to the horn
// face. The output is 10 mm from the +X end, so the case spans X -30 to +10.
// Ears 2.7 mm thick, top face 24.7 mm above the case bottom, 56 mm across.
// Two slots per ear, 49 mm apart along the case and 10 mm apart across it.
// Output boss 10 mm. Round horn: 20 mm disc, 2 mm thick, four holes on a
// 14 mm circle. Confirm that pattern on the disc in hand.
"""
    servo_path = SCRIPTS / "injora-injs035-360.nbcad.jsonc"
    servo_path.write_text(comment + body + "\n", encoding="utf-8")
    print(f"wrote {servo_path} ({servo_path.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
