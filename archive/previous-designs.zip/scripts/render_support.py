"""Cutaway of the rebuilt bearing seat and servo pocket."""

import json
from pathlib import Path

from render_drive import load_stl, render

ROOT = Path(__file__).resolve().parents[1]
SRC = Path(
    r"C:\Users\jeffg\.cursor\projects\C-Users-jeffg-dev-garden-auger-technic\agent-tools"
    r"\53a4513d-c081-4354-9048-092b35197d80.txt"
)
OUT = ROOT / "renders"


def main():
    payload = json.loads(SRC.read_text(encoding="utf-8"))
    tmp = OUT / "_housing-stl.json"
    tmp.write_text(json.dumps({"bytes_base64": payload["bytes_base64"]}), encoding="utf-8")
    tris = load_stl(tmp)
    tmp.unlink()
    # Lower clamshell only, so the seat and the servo register face are visible.
    lower = [tri for tri in tris if max(v[2] for v in tri) < 0.8]
    print("tris", len(tris), "lower", len(lower))
    mesh = [((214, 168, 72), lower)]
    OUT.mkdir(exist_ok=True)
    render(
        mesh,
        eye=(55, 145, 70),
        target=(0, 145, 0),
        up=(0, 0, 1),
        size=(1200, 800),
        path=OUT / "support-section.png",
        scale=1400,
    )
    render(
        mesh,
        eye=(0, 80, 95),
        target=(0, 130, 0),
        up=(0, 1, 0),
        size=(1200, 800),
        path=OUT / "support-seat.png",
        scale=1600,
    )


if __name__ == "__main__":
    main()
