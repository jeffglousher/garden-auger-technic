# Garden auger on an Injora continuous servo

A handheld dirt auger for a 5-year-old, driven by an Injora INJS035-360 continuous-rotation servo. The drive end is part of the auger. A Ø7.6 journal on the auger runs through two 608-2RS bearings. A printed square horn screws onto the servo with the center screw, and the auger slides onto that square. The housing lips keep it from walking off. A split housing holds the bearings and the servo, with a T-handle behind a finger guard.

## Files

| File | Role |
| --- | --- |
| `garden-auger-drive.nbcad` | The tool: auger, servo, bearings, retainer, and the split housing with the T-handle. |
| `garden-auger-slice.3mf` | Print plate: both housing halves, the one-piece auger, and the square horn. |
| `scripts/injora-injs035-360.nbcad.jsonc` | Reusable servo. One component, `INJS035-360`, for every site that needs this servo. |
| `scripts/generate.py` | Regenerates the servo script. |

Copy `injora-injs035-360.nbcad.jsonc` into another project's script folder and `include` it. An include cannot climb out of that folder. A second site is another occurrence of component `INJS035-360`.

Servo datum, used by every site:

- Origin at the center of the round-horn mating face.
- `+Z` points out of that face, toward the load.
- `+X` is the 40 mm case length. `+Y` is the 20 mm case width.
- The output is 10 mm from the `+X` end, so the case spans X −30 to +10.
- The case lies in negative Z.

## Auger drive end

The auger axis is Y. It is one solid: the flight, a thick core, and the drive hub.

| Feature | Y, mm | Size, mm |
| --- | --- | --- |
| Tip | −5.2 to 12 | point, opening to Ø14 |
| Core, through the flight | 12 to 90 | Ø14 to Ø20 |
| Neck | 90 to 105 | Ø20 down to Ø12 |
| Shoulder, against the front inner ring | 105 to 111.5 | Ø12 |
| Journal, through both bearings | 111.5 to 129.5 | Ø7.6 |
| Drive head, servo side of the bearings | 129.5 to 139.5 | Ø18 |
| Square socket | 139.5 to 131.5 | 8.8 mm across flats, 8 mm deep |
| Square horn post | 125.3 to 118.1 | 8 mm across flats, 7.2 mm long |
| Horn flange | 125.3 to 128.3 | Ø22 × 3 mm |
| Servo screw | through the horn | Ø3.4, with a Ø6 × 2.6 counterbore at the free end of the post |
| Spline pocket | in the flange face | Ø5.7 × 1.8 mm, leaving a 1.2 mm floor |

The imported flight's own core was only Ø5 at the tip and Ø9 at the top, with a thin hex socket. That shaft is gone. The core is now solid out to Ø20 under the flights, and the hub is the same piece.

The horn is its own printed part. An 8 mm square post slides into the 8.8 mm socket, 0.4 mm clear on each side, so the bridge across the socket can sag a little and still slide. The hub mouth has a 0.5 mm chamfer so the bearing starts. The post stops 0.8 mm short of the bottom of the socket, so the hub face seats on the flange. Nothing else fastens the auger to the horn.

## Bearings and retainer

Two 608-2RS bearings sit side by side from y = 111.5 to 125.5. Each one is 8 × 22 × 7 mm. Two bearings stop the auger rocking, so the servo only turns it and does not carry the side load.

- Pushing the tool into the ground: shoulder, inner rings, outer rings, rear lip of the housing.
- The flight pulling itself in: the bearing outer rings are trapped between the front lip and the rear lip, so the hub can move only the tiny amount of bearing play. That play is much smaller than the 7 mm the square is engaged, so the auger cannot walk off the post.

The old retainer ring is still in the CAD file. It is not part of this drive and does not need to be printed.

## Housing

The housing splits on the horizontal center plane. Four M3 screws clamp the split. Two sit beside the bearings in the front block, counterbored from the top. Two sit just behind the servo. The M3×5.7 heat-set inserts go in the lower half.

The grip ends locate on two printed domes, not steel pins. Each dome is on the upper half, Ø8 at the split and 3.2 mm tall, a shallow spherical cap. The lower half has the matching dish, Ø8.9 at the mouth and 3.6 mm deep, so the dome has about 0.4 mm of clearance and does not bottom out. The curve leads the halves together as they close. The domes sit on the grip centerline, 55 mm to either side of the auger axis.

| Surface | Size |
| --- | --- |
| Bearing seat | Ø22.4, from y = 111.2 to 125.8. The two 7 mm bearings occupy 111.5 to 125.5, so there is 0.3 mm at each end |
| Front opening | Ø33 through the finger guard, so the Ø31 flight clears it. Then Ø14 from y = 108.2 to 111.2, which stops the Ø22 bearing |
| Rear lip | Ø20, on the rear outer ring |
| Horn bore | Ø24 through the bulkhead, around the Ø18 drive head |
| Servo pocket | 40.8 × 20.8 mm, 0.4 mm per side, offset 10 mm to match the output. 1.0 mm clear in front of the case and 1.5 mm behind it. The case is longer on one side of the output, so the shell is built out on the short side until the outside is symmetric about the auger. The bump stays inside. |
| Ear slots | 4.5 mm for the 2.7 mm ears, both halves |
| Lead | One slot on the split, 6 mm wide and 2 mm into each half, from the pocket straight out the side wall |
| Front block | 68 × 48 mm around the bearings. The shell behind it is the same 48 mm height, so that side is one flat face. |
| Finger guard | 68 × 48 mm plate, 3.5 mm thick. Same rectangle as the front block, so the sides are one flat wall. |
| Grip | 22 × 24 mm squircle, 6 mm corners, center y = 192 |

The ears are trapped in their slots. The ear holes are not used, because a screw along the auger axis cannot be reached inside the clamshell. The pocket and the slots resist the servo's reaction torque.

The auger, bearings, horn, and servo go in as one stack, so the housing must not locate that stack twice. The bearings set the auger's position. The servo rides on the horn, with about 1 mm of room in the ear slots and the pocket. The flange is 3 mm thick, 1 mm thicker than the stock disc, so the case sits 1 mm farther back in the pocket and the rear clearance drops from 1.5 mm to 0.5 mm. The ear slots still stop the servo from backing off the horn.

The lead lays in that slot as the servo drops in. The rest of the cheek is solid.

## Assembly

The bearings go in the housing, not onto the auger first. The journal is Ø7.6, the shoulder in front of it is Ø12, and the drive head behind it is Ø18. A 608 will not pass either of those.

1. Press the square horn onto the servo spline. Drive the servo's center screw in from the square end. The head sits in the counterbore, below the end of the post.
2. Slide the square socket onto the post until the drive head seats on the flange. No other screws.
3. Melt the four inserts into the lower half. Set both 608s in the half-round seat.
4. Lower the auger and servo in together. The Ø7.6 journal lays in the bearings, the servo lays in the pocket, the ears lay in the side notches, and the lead lays in the side slot.
5. Set the upper half on the lower. The two domes drop into the dishes and pull the halves into line. Drive the two front screws (M3×12) and the two rear screws (M3×18).

![Build order on the bench](renders/step-1-bench.png)

![Finished stack into the lower half](renders/step-2-drop.png)

## Fit check print

`garden-auger-fit-check.3mf` is a short print cut from the real model. `garden-auger-fit-check.nbcad` is its CAD file. Print it before the full tool.

| Part | What to check |
| --- | --- |
| Front block, upper and lower | The real bearing seat, lips, and front screw holes. Melt two inserts into the lower piece, drop both bearings in, close it with two M3×12. The bearings should spin freely without rattling. |
| Hub 24.8, no notch | The fit-check file is older. The drive file hub is now Ø24.6, with the square socket. |
| Hub 24.6, one notch, and hub 25.0, two notches | The same hub at other sizes. Slide a bearing onto each and keep the size that goes on by hand without rocking. |
| Square horn | Press it onto the servo spline and drive the center screw. The head must sit in the counterbore. Then slide the auger socket on by hand. |

Also measure the horn face height above the servo case top with the horn on. The model uses 4.0 mm.

## Print

- Both housing halves with the split face up. The broad face at the outside sits on the bed from the finger guard through the servo shell. The T-handle is 12 mm above that face, so it is the only place that needs support.
- The auger on its side. The flight wants support on the downward blade. The square socket bridges across, and the extra clearance is there for that sag. The hub mouth is chamfered.
- The square horn with the flange on the bed and the post pointing up. The spline pocket is open on the bed, and the floor above it is 1.2 mm.
- The old retainer is not on this plate.

## Purchased parts

- Servo: Injora INJS035-360, same case as the INJS035-270 drawing. Case 40 × 20 × 37.5 mm, 41.5 mm to the horn face. Output 10 mm from one end. Ears 2.7 mm thick, 56 mm across, two slots per ear, 49 mm apart along the case and 10 mm across it. Output boss Ø10.
- Horn: printed. 8 mm square post, Ø22 × 3 mm flange, Ø5.7 pocket for the 25-tooth spline, and the servo's own center screw. The stock round disc is not used.
- Bearings: 2 × 608-2RS, 8 × 22 × 7 mm.
- Hardware: 4 × M3×5.7 heat-set inserts, 2 × M3×12 and 2 × M3×18 socket-head screws. No dowel pins. The grip ends locate on the printed domes.

## Open items

- Press the printed horn onto the servo and confirm the center screw seats in the counterbore and the square slides into the socket.
- The stock horn face is modeled 4.0 mm above the case top. This flange is 3 mm, so measure the stack once it is on the servo.
- Coupon the Ø7.6 journal in a 608. It is 0.2 mm clear per side of the 8 mm bore. The seat is 0.2 mm clear per side of the 22 mm outer ring.
- The last 45 mm of each grip end is held only by the stiffness of the bar.
- There is no battery, controller, or trigger yet.

## Source

`source/auger.STEP` and `source/coupler.STEP` are the unmodified SolidWorks 2023 exports from 2025-04-26. The coupler stays in the repo as the record of the old hex joint.
