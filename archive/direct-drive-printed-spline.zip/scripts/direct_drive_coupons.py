"""Three small nominal H25T fit coupons; radial sizing is provisional."""
import base64
import json
import math
from pathlib import Path
from cad_client import CadClient
from cad_build import Builder, profile, save_project
from build_model import circle_cut

ROOT=Path(__file__).resolve().parents[1]

def main():
    source=json.loads((ROOT/'source/h25t-female-profile.json').read_text())
    bodies=[]
    with CadClient() as c:
        c.call('cad_new_project',{})
        for i,radial in enumerate([0,-.05,-.10]):
            name=f'Spline fit {chr(65+i)} - major {6.1+2*radial:.2f} mm'
            body=Builder(c).revolve(name,[(0,1.7),(4,1.7),(4,8),(0,8)],'new_body',[])['created_body_id']
            circle_cut(c,name+' bore',[(0,0)],6.1,2,2.05,body)
            m=c.call('cad_project_model');m=json.loads(m) if isinstance(m,str) else m
            s=next(s for s in m['sketches'] if s['name']==name+' bore')
            points=[]
            for x,z in source['points_xz_mm']:
                radius=math.hypot(x,z)
                points.append((x*(radius+radial)/radius,z*(radius+radial)/radius))
            profile(s,points)
            c.call('cad_load_project_model',{'model_json':json.dumps(m)})
            c.call('solid_move_copy',{'body_ids':[body],'translation':{'x':i*22,'y':0,'z':0},
                'pivot':{'x':0,'y':0,'z':0},'copy':False})
            c.call('set_body_appearance',{'body_id':body,'material_name':'PETG','filament_type':'PETG',
                'color_name':'Adapter gray','color':{'r':190,'g':195,'b':202,'a':255}})
            bodies.append({'body':body,'label':chr(65+i),'radial_adjustment_mm':radial,
                'major_diameter_mm':6.1+2*radial,'minor_diameter_mm':5.4+2*radial})
        m=c.call('cad_project_model');m=json.loads(m) if isinstance(m,str) else m
        m['document']['name']='Nominal H25T PETG fit coupons A B C - unqualified'
        m['visibility']['hidden_sketch_names']=[s['name'] for s in m['sketches']]
        m['visibility']['hidden_datum_plane_ids']=[p['datum_id'] for p in m['datum_planes']]
        c.call('cad_load_project_model',{'model_json':json.dumps(m)})
        assert c.call('solid_export_preflight')['ok']
        save_project(c,ROOT/'garden-auger-spline-fit.nbcad')
        r=c.call('solid_export_3mf',{'body_ids':[b['body'] for b in bodies],'scope':'definition',
            'linear_deflection':.08,'angular_deflection':.2,'slicer_target':'bambu_studio'})
        (ROOT/'.build/direct-drive/coupons-raw.3mf').write_bytes(base64.b64decode(r['bytes_base64']))
        (ROOT/'.build/direct-drive/coupons.json').write_text(json.dumps(bodies,indent=2))
        print('Fit coupons A/B/C saved; select by physical shaft fit, not diameter alone',flush=True)

if __name__=='__main__':main()
