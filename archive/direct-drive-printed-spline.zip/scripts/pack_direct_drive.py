"""Package the direct-drive prototype without changing release B artifacts."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile
import numpy as np
from print_packer import pack, mesh_from_object, component_count, CORE, M

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'.build/direct-drive'
NOTES='''Direct-to-spline FIT PROTOTYPE for INJORA INJS035-360.
Four PETG parts: yellow chassis halves, orange auger, gray integrated 25T adapter.
One PLA part: teal full loose wear sleeve. No ring lock or clip.
No separate servo horn and no four M4 mounting screws.
Use only a factory-compatible M3 center screw at the adapter; inspect actual shaft and thread depth.
Nominal female profile is supplier H25T geometry, major 6.10 / minor 5.40 mm, not measured INJORA tooth form.
Print A/B/C spline coupons first. A=6.10, B=6.00, C=5.90 major diameter; radial adjustments 0/-0.05/-0.10 mm.
Full adapter currently uses A; change its native spline sketch to the physically selected fit before printing/loading.
Nominal spline socket depth 2.0 mm; engagement and case/shaft clearances must be measured.
Printed torque capacity, creep, wear and service life have not been qualified.
Keep the 14 mm square and 28 mm auger hub; integral collar retained only by clamshell.
Native CAD and portable 3MF material/color metadata are explicit; select actual slicer profiles.
Chassis uses 4 ruthex RX-M3x5.7 inserts, 2 M3x12 front and 2 M3x18 rear screws.
Separate PLA and PETG printing avoids filament changes and purge.
'''


def small_plate(source,target,coupons=False):
    with zipfile.ZipFile(source) as z:entries={n:z.read(n) for n in z.namelist()}
    xml=ET.fromstring(entries['3D/3dmodel.model'])
    objects=xml.findall('m:resources/m:object',M)
    build=xml.find('m:build',M);build.clear()
    rotation=np.array([[1,0,0],[0,0,1],[0,-1,0]])
    out=ROOT/'print-parts/direct-drive';out.mkdir(parents=True,exist_ok=True)
    report=[]
    for i,obj in enumerate(objects):
        mesh=mesh_from_object(obj)
        assert component_count(mesh)==1
        vertices=mesh.vertices@rotation.T
        translation=np.array([8+i*23,8,0])-vertices.min(axis=0)
        bounds=np.array([vertices.min(axis=0),vertices.max(axis=0)])+translation
        assert np.all(bounds[0]>=0) and np.all(bounds[1,:2]<256)
        major=6.1-i*.1
        label=f'PETG - Spline fit {chr(65+i)} - major {major:.2f}' if coupons else 'PETG - Integrated 25T square adapter'
        obj.set('name',label)
        ET.SubElement(build,f'{{{CORE}}}item',{'objectid':obj.get('id'),
            'transform':' '.join(f'{n:.9g}' for n in [*rotation.T.reshape(-1),*translation])})
        standalone=mesh.copy();standalone.vertices=vertices-vertices.min(axis=0)
        filename=f'spline-fit-{chr(65+i).lower()}-{major:.2f}.stl' if coupons else 'petg-square-adapter.stl'
        standalone.export(out/filename)
        report.append({'name':label,'closed':True,'connected_components':1,
            'volume_mm3':float(mesh.volume),'bounds_mm':bounds.tolist()})
    entries['3D/3dmodel.model']=ET.tostring(xml,encoding='utf-8',xml_declaration=True)
    entries['Metadata/print-notes.txt']=NOTES.encode()
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for name,data in entries.items():z.writestr(name,data)
    return report


def main():
    report={'assembly':pack(OUT/'assembly-raw.3mf',ROOT/'garden-auger-direct-drive.3mf',
        individual_dir='print-parts/direct-drive',material_plates=False,print_notes=NOTES),
        'adapter':small_plate(OUT/'adapter-raw.3mf',ROOT/'garden-auger-direct-adapter.3mf'),
        'coupons':small_plate(OUT/'coupons-raw.3mf',ROOT/'garden-auger-spline-fit.3mf',coupons=True)}
    proof=json.loads((ROOT/'direct-drive-verification.json').read_text())
    proof['desktop_compatibility']=json.loads((OUT/'desktop-compatibility.json').read_text())
    proof['print_checks']=report
    proof['artifact_sha256']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
        [ROOT/'garden-auger-direct-drive.nbcad',ROOT/'garden-auger-direct-drive.3mf',
         ROOT/'garden-auger-direct-adapter.3mf',ROOT/'garden-auger-spline-fit.nbcad',ROOT/'garden-auger-spline-fit.3mf']}
    (ROOT/'direct-drive-verification.json').write_text(json.dumps(proof,indent=2))
    print('Five-part direct assembly, single adapter and three small fit coupons packaged',flush=True)

if __name__=='__main__':main()
