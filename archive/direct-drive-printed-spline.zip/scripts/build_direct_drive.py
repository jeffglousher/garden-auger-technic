"""Direct-to-spline prototype; retain release B as the metal-horn fallback.

The nominal female H25T tooth form comes from a supplier STEP section.
INJORA publishes the major shaft diameter and tooth count, not full tooth
geometry or exposed length. This file therefore does not certify shaft fit.
"""
import base64
import json
import math
from pathlib import Path

from cad_client import CadClient
from cad_build import Builder, profile, save_project
from build_model import configure, rear_pads, circle_cut
from model_cleanup import clean_checked

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'.build/direct-drive'
SPLINE_FRONT=148.5
SPLINE_REAR=150.5
HEAD_SEAT=146.1


def model_value(c):
    m=c.call('cad_project_model')
    return json.loads(m) if isinstance(m,str) else m


def setup():
    m=configure()
    sketches={s['name']:s for s in m['sketches']}
    sketches['Sketch101']['snapshot']['entities'][0][1]['radius']=14.0
    next(e for e in m['extrudes'] if e['feature_id']==293)['extent']['distance']=5.0
    # The 28 mm flange fits within the journal-size rear chamber. No broad
    # metal-horn cavity or four M4 mounting features are needed.
    profile(sketches['Chassis integral thrust stops and journal seat'],
        [(110.9,0),(110.9,14.8),(112.9,14.8),(113.7,15.6),
         (113.7,17.8),(117.3,17.8),(117.3,15.5),(118.5,14.8),
         (120.3,14.8),(120.3,17.8),(131.2,17.8),(131.2,14.8),
         (153,14.8),(153,0)])
    old='Metal horn pilot and center screw head relief'
    new='Direct adapter axial screw access and head seat'
    sketches[old]['name']=new
    profile(sketches[old],[(129.3,0),(129.3,3.2),(HEAD_SEAT,3.2),(HEAD_SEAT,0)])
    for r in m['revolves']:
        if r['sketch_name']==old:r['sketch_name']=new
    for f in m['document']['history']['features']:
        if f['name']==old:f['name']=new
    m['document']['name']='Garden auger - integrated 25T direct-drive fit prototype'
    # Release B's drawings describe a separate horn and must not accompany
    # this different connection. Its measured release drawing stays intact.
    m['drawings']['sheets']=[]
    return m


def check_assembly(c,m):
    auger=next(o['id'] for o in m['assembly']['component_structure']['occurrences'] if o['component_id']==8)
    adapter=next(o['id'] for o in m['assembly']['component_structure']['occurrences'] if o['component_id']==14)
    checks=[]
    for shift,angle in [(0,0),(-.3,0),(.3,0),(0,45),(0,90)]:
        q=[0,math.sin(math.radians(angle)/2),0,math.cos(math.radians(angle)/2)]
        for occurrence,dy in [(auger,shift),(adapter,0)]:
            c.call('assembly_set_occurrence_pose',{'occurrence_id':occurrence,
                'local_pose':{'translation':[0,dy,0],'rotation':q}})
        r=c.call('assembly_interference_check',{'clearance_threshold_mm':.05})
        assert r['exact']
        unexpected=[p for p in r['pairs'] if p['interfering'] and {p['body_a'],p['body_b']}!={15,90}]
        assert not unexpected,unexpected
        checks.append({'auger_shift_mm':shift,'common_rotation_deg':angle,'exact':True,'unintended_overlap':False})
    for shift in [-.31,.31]:
        for occurrence,dy in [(auger,shift),(adapter,0)]:
            c.call('assembly_set_occurrence_pose',{'occurrence_id':occurrence,
                'local_pose':{'translation':[0,dy,0],'rotation':[0,0,0,1]}})
        r=c.call('assembly_interference_check',{'clearance_threshold_mm':.05})
        assert r['exact'] and any(p['interfering'] and 15 in {p['body_a'],p['body_b']}
            and bool({26,46}&{p['body_a'],p['body_b']}) for p in r['pairs']),r
        checks.append({'auger_shift_mm':shift,'chassis_blocks_overtravel':True,'exact':True})
    c.call('cad_load_project_model',{'model_json':json.dumps(m)})
    return checks


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    spline=json.loads((ROOT/'source/h25t-female-profile.json').read_text())
    with CadClient() as c:
        c.call('cad_load_project_model',{'model_json':json.dumps(setup())})
        rear_pads(c)
        Builder(c).revolve('Direct adapter integral spline boss',
            [(146.0,3.2),(HEAD_SEAT,3.2),(HEAD_SEAT,1.7),(SPLINE_REAR,1.7),
             (SPLINE_REAR,8),(146.0,8)],'join',[216])
        circle_cut(c,'Integrated nominal H25T female spline',[(0,0)],6.1,
                   SPLINE_FRONT,SPLINE_REAR-SPLINE_FRONT+.05,216)
        m=model_value(c)
        sketch=next(s for s in m['sketches'] if s['name']=='Integrated nominal H25T female spline')
        profile(sketch,[tuple(p) for p in spline['points_xz_mm']])
        c.call('cad_load_project_model',{'model_json':json.dumps(m)})
        m,cleanup=clean_checked(c,m,221)
        for o in m['assembly']['component_structure']['occurrences']:
            if o['component_id']==14:o['name']='Integrated 25T direct-to-servo adapter - fit prototype'
        c.call('cad_load_project_model',{'model_json':json.dumps(m)})
        checks=check_assembly(c,m)
        preflight=c.call('solid_export_preflight')
        assert preflight['ok'] and not preflight['timeline_errors'],preflight
        m=save_project(c,ROOT/'garden-auger-direct-drive.nbcad')
        (OUT/'model.json').write_text(json.dumps(m))
        (OUT/'scene.json').write_text(json.dumps(c.call('solid_scene')))
        for ids,name in [([26,46,15,90,216,221],'assembly-raw.3mf'),([216],'adapter-raw.3mf')]:
            r=c.call('solid_export_3mf',{'body_ids':ids,'scope':'definition',
                'linear_deflection':.08,'angular_deflection':.2,'slicer_target':'bambu_studio'})
            (OUT/name).write_bytes(base64.b64decode(r['bytes_base64']))
        report={'status':'fit prototype; physical shaft geometry and torque capacity unqualified',
            'servo':'INJORA INJS035-360, published 5.9 mm / 25T output',
            'removed_hardware':['Separate metal servo horn','4 x M4 horn mounting screws'],
            'remaining_adapter_hardware':'one factory-compatible M3 center screw',
            'nominal_profile':spline,'adapter_dimensions_mm':{
                'square_peg':14,'peg_corner_radius':1,'peg_length':11.6,
                'flange_diameter':28,'flange_thickness':5,'spline_boss_diameter':16,
                'spline_bore_depth':2,'screw_clearance':3.4,'head_access_diameter':6.4,
                'minimum_web_between_head_seat_and_spline_bottom':2.4},
            'shaft_reference_only':{'assumed_tip_y':148.7,'assumed_shoulder_y':150.7,
                'nominal_engagement':1.8,'nominal_tip_to_bore_bottom_gap':.2,
                'nominal_boss_to_shoulder_gap':.2,
                'warning':'Exposed shaft length/shoulder geometry are not specified by INJORA; this is not a verified shaft stack.'},
            'center_screw_inspection':{'nominal_underhead_seat_to_shaft_tip':2.6,
                'required_measured_seat_to_tip_for_M3x6':[2.4,2.8],
                'required_usable_thread_depth_min':4.0,
                'warning':'Select screw by actual seating, thread depth and tip clearance; screw must not bottom.'},
            'square_fit_stack':{'required_flange_face_y':[140.95,141.25],
                'required_flange_face_from_front_chassis_thrust_stop':[27.25,27.55],
                'required_drive_axis_offset_max':.5,
                'engagement_min':9.35,'engagement_max':10.85,
                'tip_bottom_gap_min':1.05,'hub_flange_gap_min':.75,
                'note':'Conditional on printed +/-0.10 mm critical limits and measured installed flange location.'},
            'cleanup':cleanup,'preflight':preflight,'assembly_checks':checks,
            'torque':{'published_stall_Nm':35*9.80665*.01,
                'tangential_force_at_5_9_mm_diameter_N':35*9.80665*.01/.00295,
                'printed_adapter_load_rating':'not established; requires bench qualification'},
            'manufacturing_controls':{
                'datum_A':'center screw underhead seating plane Y=146.1',
                'datum_B':'female spline derived pitch axis',
                'square':'14 / R1 BASIC; total surface profile 0.10 to A|B, free clocking',
                'seat':'flatness 0.10; seating-location extrema included in axial inspection',
                'female_spline':'nominal supplier H25T profile; final fit allowance selected from coupons, no certified tolerance yet'},
            'physical_acceptance':['Select the coupon that seats snugly without splitting and has positive tooth engagement.',
                'Measure actual exposed spline length, tip clearance and nonrotating case clearance; maximize engagement before loading.',
                'Verify center screw clamps the adapter and does not bottom, then inspect installed flange position and square clearances.',
                'Qualify loaded torque, stall behavior and creep on the completed PETG adapter; CAD clearance is not proof of strength.']}
        (ROOT/'direct-drive-verification.json').write_text(json.dumps(report,indent=2))
        print('Direct-drive prototype saved: no separate horn, no M4 pattern',flush=True)


if __name__=='__main__':main()
