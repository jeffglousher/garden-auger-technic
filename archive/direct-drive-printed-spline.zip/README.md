# Garden auger — direct-drive prototype and release B fallback

The new [direct-drive CAD](garden-auger-direct-drive.nbcad) combines the horn and square adapter into **one gray PETG part with a nominal 25-tooth female socket**. It mounts directly on the INJORA output spline and uses one factory-compatible M3 center screw. The separate metal horn and four M4 screws are omitted. The 14 mm square drive, 28 mm auger hub, loose teal PLA sleeve and clamshell-only collar retention remain.

![Integrated spline and square adapter](renders/direct-drive-adapter.png)

This is a **fit prototype, not a qualified 35 kg·cm drive**. Torque is carried by positive tooth engagement; the center screw retains the adapter axially. Smooth friction alone is not the design basis. INJORA publishes a 5.9 mm /25T output but does not provide its full tooth form or exposed length. The provisional socket uses the supplier H25T female profile from the archived goBILDA STEP, with nominal 6.10 mm major /5.40 mm minor diameters. Compatibility with the actual shaft must be established physically.

Print the small [PETG spline-fit coupons](garden-auger-spline-fit.3mf) first: **A = 6.10, B = 6.00, C = 5.90 mm nominal major diameter**. B/C apply −0.05 /−0.10 mm radial adjustments to the same 25-tooth profile; they are trial geometries, not certified fits. Choose a snug fit with full tooth engagement that seats without splitting. Check tooth roots and shaft length as well as major diameter. The full adapter currently uses **A**. Transfer the physically selected coupon profile into its native `Integrated nominal H25T female spline` sketch before the final print.

The adapter has a Ø28 ×5 flange, Ø16 spline boss, a 2 mm-deep nominal spline socket, Ø3.4 center-screw passage and Ø6.4 screw-head access through the square peg. The web between the screw seat and spline bottom is 2.4 mm. The reference servo assumes a 2 mm exposed shaft, giving only **1.8 mm nominal engagement and 0.2 mm tip/shoulder clearances**; these are unverified assumptions, not incoming acceptance dimensions. Measure the actual shaft and maximize spline engagement while preserving tip and stationary-case clearance before loading. Do not assume this short reference engagement can transmit stall torque.

For an M3 ×6 center screw, inspect actual underhead-seat-to-shaft-tip distance **2.6 ±0.2 mm** and at least **4.0 mm usable thread depth**. Otherwise select a factory-compatible length from the measured stack. The screw must clamp the adapter without bottoming. After tightening, the adapter's auger-facing flange must lie **27.40 ±0.15 mm behind the front chassis thrust-stop face**, with drive-axis offset ≤0.50 mm from the assembled journal axis. The existing square engagement and bottom-gap limits below are conditional on these installed limits and the critical printed dimensions.

The rear chassis cavity is reduced to Ø29.6, adding wall around the smaller adapter. Exact native CAD checks cover the nominal assembly, both ±0.30 mm travel limits, common 45°/90° rotation and chassis-blocked overtravel at ±0.31 mm. All five print parts are closed and connected and fit a 256 mm bed. PETG remains yellow #E5AE3C for the chassis, orange #D57E37 for the auger and gray #BEC3CA for the adapter; the sleeve remains PLA teal #37AAA1. Inserts and chassis screw sizes are unchanged.

Direct-drive deliverables: [five-part 3MF](garden-auger-direct-drive.3mf), [single-adapter 3MF](garden-auger-direct-adapter.3mf), [coupon CAD](garden-auger-spline-fit.nbcad), [individual STLs](print-parts/direct-drive), [all parts](renders/direct-drive-all-parts.png), [exploded assembly](renders/direct-drive-exploded.png), and [dimension/verification report](direct-drive-verification.json). The direct-drive CAD deliberately excludes the release B horn drawings. Its provisional manufacturing controls are recorded in the verification report; spline allowances and the shaft stack remain open until physical fit. Qualify torque, stalls and PETG creep before service.

Regenerate this prototype with `scripts/build_direct_drive.py`, `scripts/direct_drive_coupons.py`, `scripts/desktop_export.py --direct`, `scripts/pack_direct_drive.py` (trimesh/manifold3d), and `scripts/render_direct_drive.py` (Pillow). The original metal-horn release B files and drawings below are retained as the fallback and do not describe the direct-drive connection.

## Release B — metal-horn fallback

Ready for a **fit-check print and bench qualification**. CAD, drawings, both bearing variants and print packages have been rebuilt and checked. Physical spline fit, printer capability, loaded strength and wear have not been tested.

The PETG auger has a Ø28 journal, a rounded square socket and an integral Ø34 collar. **Both collar faces are retained by the chassis clamshell.** The full PLA sleeve slides over the journal from the drive end and remains loose. No clip, ring lock or separate retention hardware is used.

![Native CAD exploded assembly](renders/cad-exploded.png)

![All parts](renders/auger-all-parts.png)

## Servo and metal horn

Use the **INJORA INJS035-360, 35KG continuous-rotation servo** and **goBILDA 1906-0025-0032 metal 25T horn**. The standard H25T connection is selected from the published 5.9 mm /25T servo specification and horn family; confirm its fit on the actual INJORA shaft at first assembly. The original unmeasured nylon-horn mount and printed round spline placeholder have been removed.

The [manufacturer STEP](source/horn-1906-0025-0032/1906-0025-0032.STEP) defines the nominal horn boss, seating face and four threaded M4 mounting holes. Vendor manufacturing tolerances were not provided; the drawing uses incoming inspection requirements instead of claiming supplier tolerances.

- PETG adapter: Ø34 ×7 flange, 14 BASIC square /R1 BASIC corners, 11.6 mm peg length. Four Ø4.6 holes with Ø7.4 ×4.4 counterbores accept **four M4 ×6 ISO4762 screws**, clear of the peg.
- Horn pocket: Ø14.5 ×2.3 deep for the nominal Ø13.98 ×2.0 metal boss. The Ø6.4 center-head relief clears the **M3 ×6 center screw**.
- M4 engagement: 3.4 mm nominal, at least 3.1 mm under the stated tolerances; minimum head recess 0.3 mm.
- Verify **at least 4.0 mm usable M3 thread depth** and **2.6 ±0.2 mm from the screw's under-head seating face to the shaft tip** before installing the specified center screw. The 3.1–3.7 mm engagement range leaves at least 0.3 mm at the thread bottom. If either inspection fails, use a factory-compatible screw. Confirm the spline seats without force and provides at least 2 mm engagement.
- Installed horn face: **34.40 ±0.15 mm behind the front chassis thrust stop**. Installed drive-axis offset from the assembled journal axis: **≤0.50 mm radial**. Inspect these assembly requirements, which include purchased-part variation.

Primary sources: [INJORA servo](https://www.injora.com/products/injora-injs035-360-35kg-waterproof-digital-servo-360-steering-winch-wheel-for-rc), [goBILDA horn](https://www.gobilda.com/1906-series-lightweight-servo-hub-25-tooth-spline-32mm-diameter//), [original STEP download](https://www.gobilda.com/content/step_files/1906-0025-0032.zip).

## Dimensions and GD&T

The [four-page controlled drawing](output/pdf/garden-auger-release-B.pdf) defines datum frames, basic square geometry, surface-profile controls, mounting-hole position, face flatness and thrust-face perpendicularity. Native CAD contains four drawing sheets and manufacturing notes. All dimensions are millimeters.

Critical printed dimensions require ±0.10 mm acceptance. Basic square surfaces use a **0.10 mm total profile zone**, including size, form and location; those contributions are not counted again. Functional axial dimensions are inspected at their surface extrema, so face form stays inside the size envelope. The stack uses arithmetic worst cases, including ±0.15 mm installed horn-face variation:

- Collar 3.00 ±0.10 in a 3.60 ±0.10 capture span: **0.40–0.80 mm total end float**.
- Square engagement: **9.35–10.85 mm**.
- Tip-to-socket-bottom gap: **≥1.05 mm**.
- Hub-to-adapter-flange gap: **≥0.75 mm**.
- Ø28 journal in Ø29.6 seat: **≥0.70 mm radial clearance**, leaving **0.20 mm** at the permitted 0.50 mm axis offset.
- Sleeve Ø34 /bore Ø28.6 ×10.4 long in Ø35.6 cavity: **≥0.90 mm combined radial float**.
- Square flat clearance: **≥0.10 mm per side**. Socket 14.4 BASIC /R1.2 BASIC, 12 deep. Hub corner wall: 4.31 mm nominal, 3.81 mm at the outer mouth chamfer.

Torque transfers through rounded leading corners after clearance is taken up. Nominal geometric backlash is about 3.89° total; exact checks show clearance at 1.8° relative rotation and contact at 2.2°.

These are **required acceptance limits, not measured FDM capability or rated load capacity**. Print and measure the fit coupon in the intended materials/settings, finish mating surfaces if needed, and check free rotation, positive end float and the installed horn-face/axis limits before a loaded trial. PLA/PETG wear or friction benefit remains untested.

## Materials and heat-set inserts

Native CAD and 3MF assignments are explicit:

- Chassis halves: **PETG, yellow #E5AE3C**.
- One-piece auger: **PETG, orange #D57E37**.
- Square adapter: **PETG, gray #BEC3CA**.
- Loose sleeve: **PLA, teal #37AAA1**.
- Purchased servo: blue gray #4B6277; purchased anodized aluminum horn: #AEB8C4. Both are excluded from print packages.

Use **four brass ruthex RX-M3x5.7 inserts**, Ø4.6 ×5.7, M3 thread. Lower chassis pilots are **Ø4.00 ×6.70 deep**. Inspect actual printed hole size and a depth of at least the actual insert length +1 mm; install flush with the split face. Checked surrounding wall is **at least 4.45 mm after dimensional allowance**, above the 1.6 mm minimum. Rear pads sit behind the wire channel.

Upper screw clearance is Ø3.4, with Ø6.2 head recesses. Use **two M3 ×12 front** and **two M3 ×18 rear ISO4762 screws**. Nominal insert engagement is 4.0 /5.3 mm respectively. All four screw passages and insert mouths are checked open. Fastener cuts follow structural joins.

[ruthex datasheet](https://www.igo3d.com/mediafiles/Sonstiges/Ruthex/ruthex_Datenblatt_RX-Serie.pdf), [exact insert](https://www.ruthex.de/products/ruthex-gewindeeinsatz-m3-100-stuck-rx-m3x5-7-messing-gewindebuchsen).

## Print and assembly

3MF contains geometry, bed placement, material names and colors. Choose actual printer, filament and support profiles in the slicer. Separate PETG and PLA plates allow single-material printing with no purge tower. STL does not store material or color.

Chassis halves rest on their outside faces; adapter and sleeve are upright. The auger lies horizontally to keep its shaft along the layer planes; support is needed under the flight and unsupported underside. Use substantial perimeters, qualify the coupon, and preserve the collar fillets and socket radii.

1. Install inserts in the lower chassis; allow it to cool.
2. Mount the metal horn and appropriate center screw on the servo. Inspect spline engagement, thread depth and seating.
3. Bolt the adapter to the metal horn with four M4 ×6 screws. Access the counterbores from the auger side before mating the square.
4. Slide the PLA sleeve onto the journal, engage the square and place the assembly in the lower chassis.
5. Close the clamshell using the four M3 screws. Check rotation, end float and installed face/axis limits. The integral collar alone provides retention.

The direct-bearing variant omits the sleeve. It uses the same Ø29.6 journal clearance, collar stops, auger and adapter.

## Deliverables and checks

- [Editable CAD](garden-auger-drive.nbcad), [five-part 3MF](garden-auger-slice.3mf), [PETG plate](garden-auger-petg.3mf), [PLA sleeve plate](garden-auger-pla-bushing.3mf).
- [Fit-check CAD](garden-auger-fit-check.nbcad), [fit-check 3MF](garden-auger-fit-check.3mf), [no-ring CAD](garden-auger-no-ring.nbcad), [no-ring 3MF](garden-auger-no-ring.3mf), [individual STL files](print-parts).
- [GD&T drawing PDF](output/pdf/garden-auger-release-B.pdf), [dimension audit](dimension-audit.json), [checks and artifact hashes](captured-verification.json).

Exact native checks cover both thrust limits, common 45/90° rotation, chassis-blocked overtravel, ±0.50 mm isolated journal offsets, sleeve installation and relative square contact. Print meshes are closed and connected, do not overlap on a 256 mm bed and sit at Z0. The editable auger component contains its core and original imported flight as two overlapping construction bodies; the packer produces one connected printed solid and checks that the flight remains.

Active history has 122 features and no suppressed leftovers. Desktop-compatible CAD is checked against the newer engine for identical mesh vertices/triangles, preserved materials and drawing sheets. The construction seed retains newer editable region data. Retired designs and builders are in SHA256-verified [archives](archive).

Regenerate with the installed native stdio engine:

```powershell
uv run --no-project python scripts/build_model.py
uv run --no-project python scripts/check_captured.py
uv run --no-project --python 3.12 --with trimesh python scripts/audit_dimensions.py
uv run --no-project --python 3.12 --with reportlab --with pymupdf python scripts/release_drawings.py
Copy-Item .build/drawing-project.nbcad garden-auger-drive.nbcad
uv run --no-project --python 3.12 --with trimesh --with manifold3d python scripts/pack_captured.py
uv run --no-project --with pillow python scripts/render_captured.py
uv run --no-project --with pillow python scripts/render_mating.py
```

`scripts/desktop_export.py` additionally verifies/exports through the isolated desktop recorded in `.build/cad-launch.json`. Run it before final packing to keep CAD hashes current. `scripts/cad_review.py` displays temporary inspection poses without saving them.
