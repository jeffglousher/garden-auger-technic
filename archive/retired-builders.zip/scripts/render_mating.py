"""Dimensioned views of the native square mating and chassis thrust surfaces."""

import json
from pathlib import Path
import numpy as np
import trimesh
from shapely.geometry import Polygon
from PIL import Image, ImageDraw
from render_common import font

ROOT=Path(__file__).resolve().parents[1]
BG=(17,21,27);PANEL=(24,28,34);TEXT=(238,244,249);MUTED=(178,194,210)
ORANGE=(213,126,55);GRAY=(190,195,202);TEAL=(55,170,161);YELLOW=(229,174,60)


def main():
    scene=json.loads((ROOT/'.build/scene.json').read_text())
    audit=json.loads((ROOT/'dimension-audit.json').read_text());sq=audit['square']
    out=Image.new('RGB',(1800,1300),BG);d=ImageDraw.Draw(out)
    def text(x,y,s,size=23,color=TEXT,bold=False):d.text((x,y),s,font=font(size,bold),fill=color)
    def arrow(a,b,color=MUTED):
        d.line([a,b],fill=color,width=2)
        delta=np.array(b)-a;delta=delta/max(np.linalg.norm(delta),1);side=np.array([-delta[1],delta[0]])
        for p,v in [(np.array(a),delta),(np.array(b),-delta)]:
            d.polygon([tuple(p),tuple(p+v*10+side*4),tuple(p+v*10-side*4)],fill=color)
    def dim(a,b,label,offset=-34):
        y=a[1]+offset;d.line([a,(a[0],y)],fill=MUTED,width=1);d.line([b,(b[0],y)],fill=MUTED,width=1)
        arrow((a[0],y),(b[0],y));w=d.textbbox((0,0),label,font=font(21))[2]
        text((a[0]+b[0]-w)/2,y-28,label,21)
    text(38,22,'Auger + square drive | Checked mating surfaces',37,bold=True)
    text(38,76,'Native model sections • dimensions in mm • prototype print fit',23,MUTED)
    for x,c,label in [(38,ORANGE,'PETG auger'),(380,GRAY,'PETG square adapter'),(800,TEAL,'PLA loose sleeve'),(1220,YELLOW,'PETG clamshell')]:
        d.rounded_rectangle((x,120,x+28,148),radius=5,fill=c);text(x+40,116,label,24)
    d.rounded_rectangle((25,174,690,774),radius=18,fill=PANEL)
    text(50,194,'1  Looking along the shaft',28,bold=True)
    cx,cy,scale=352,470,14
    def box(width):
        h=width*scale/2;return(cx-h,cy-h,cx+h,cy+h)
    d.ellipse(box(28),fill=ORANGE)
    d.rounded_rectangle(box(sq['female_across_flats_mm']),radius=1.2*scale,fill=BG)
    d.rounded_rectangle(box(sq['male_across_flats_mm']),radius=scale,fill=GRAY)
    d.ellipse(box(3.4),fill=BG)
    dim((cx-7.2*scale,cy-7.2*scale),(cx+7.2*scale,cy-7.2*scale),'Socket 14.4 / R1.2',-70)
    dim((cx-7*scale,cy+7*scale),(cx+7*scale,cy+7*scale),'Peg 14.0 / R1.0',55)
    text(51,693,'Ø28 hub • wall 4.31 / 3.81 at mouth',22)
    text(51,731,'Centered clearance: 0.20 per side',22,MUTED)
    d.rounded_rectangle((715,174,1775,774),radius=18,fill=PANEL)
    text(744,194,'2  Longitudinal section through the axis',28,bold=True)
    y0,px,py,s=110,1030,480,12
    def transform(p):return (px+(p[0]-y0)*s,py-p[1]*s)
    def draw_geometry(shape,color):
        polys=[shape] if shape.geom_type=='Polygon' else list(shape.geoms)
        for p in polys:
            if p.geom_type!='Polygon':continue
            d.polygon([transform(q) for q in p.exterior.coords],fill=color)
            for ring in p.interiors:d.polygon([transform(q) for q in ring.coords],fill=PANEL)
    for body,color in [(26,YELLOW),(46,YELLOW),(15,ORANGE),(221,TEAL),(216,GRAY)]:
        native=next(b['mesh'] for b in scene['bodies'] if b['id']==body)
        mesh=trimesh.Trimesh(vertices=np.array(native['positions']).reshape(-1,3),
                            faces=np.array(native['indices']).reshape(-1,3),process=False)
        section=mesh.section(plane_origin=[0,0,0],plane_normal=[1,0,0])
        if section is None:continue
        shape=Polygon()
        for loop in section.discrete:
            poly=Polygon(loop[:,[1,2]])
            if poly.is_valid:shape=shape.symmetric_difference(poly)
        # Crop this illustration to the drive only, not the flight/handle.
        from shapely.geometry import box as crop_box
        draw_geometry(shape.intersection(crop_box(110.9,-19,144.3,19)),color)
    # Axis and axial dimensions are tied to the actual modeled coordinates.
    d.line([transform((110.9,0)),transform((145,0))],fill=MUTED,width=1)
    dim(transform((129.5,8)),transform((139.5,8)),'10.0 engagement',-28)
    dim(transform((127.5,0)),transform((129.5,0)),'2.0 tip gap',46)
    text(747,702,'Socket depth 12.0 • end float ±0.30',22)
    text(747,739,'At stops: engagement ≥9.7 • tip gap ≥1.7 • flange gap ≥0.5',21,MUTED)
    # Direct chassis stops: mark both cut faces, avoiding any bearing-lock implication.
    for y,r,label,tx,ty in [(113.7,16.2,'Pull stop',745,260),(139.8,13.2,'Push stop',1490,260)]:
        p=transform((y,r));d.ellipse((p[0]-5,p[1]-5,p[0]+5,p[1]+5),fill=(250,242,230))
        d.line([p,(tx+55,ty+35)],fill=TEXT,width=2);text(tx,ty,label,22,bold=True)
    d.rounded_rectangle((25,800,1775,1275),radius=18,fill=PANEL)
    text(50,822,'What each surface does',29,bold=True)
    rows=[
      ('Torque', 'Square peg corners contact the socket sides after taking up clearance.', GRAY),
      ('Strength', 'Corner wall: 4.31 mm in the hub; 3.81 mm at the chamfered mouth.', ORANGE),
      ('Retention', 'Integral auger faces meet the clamshell stops. The sleeve has no lock.', YELLOW),
      ('Running surface', 'Ø28 hub / Ø28.4 sleeve bore; Ø34 sleeve / Ø34.4 chassis seat.', TEAL),
      ('Heat-set inserts', '4 × ruthex RX-M3x5.7: Ø4.6 × 5.7; CAD pilots Ø4.0 × 6.7 deep.', YELLOW),
    ]
    for i,(title,detail,color) in enumerate(rows):
        y=880+i*58;d.rectangle((52,y+4,63,y+32),fill=color)
        text(79,y,title,23,bold=True);text(340,y,detail,23,MUTED)
    d.line((50,1180,1750,1180),fill=(64,74,87),width=1)
    text(50,1199,'Servo confirmed: INJORA INJS035-360 • 5.9 mm / 25T shaft.',22)
    text(50,1238,'Open fit: the horn attachment is unqualified; the round pocket does not model a 25T spline.',22,(246,173,115))
    out.save(ROOT/'renders/square-mating-dimensions.png')


if __name__=='__main__':main()
