"""Build a large square drive, retained only by the chassis clamshell.

The optional plain PLA sleeve is free to rotate. No clip, groove, key,
bearing retainer or other retention object is part of this design.
"""

import base64
import json
import math
from pathlib import Path
import sys

from cad_client import CadClient
from cad_build import Builder,prepare_baseline,profile,save_project
from model_cleanup import clean_checked

ROOT=Path(__file__).resolve().parents[1]
USE_RING='--no-ring' not in sys.argv
HUB_D=28.0
PEG_W=14.0
SOCKET_W=14.4
SOCKET_DEPTH=12.0


def rounded_square(sketch,width,radius):
    h=width/2;r=radius
    profile(sketch,[(-h+r,-h),(h-r,-h),(h,-h+r),(h,h-r),
                   (h-r,h),(-h+r,h),(-h,h-r),(-h,-h+r)],{
        1:((h-r,-h+r),r,1.5*math.pi,2*math.pi),
        3:((h-r,h-r),r,0,.5*math.pi),
        5:((-h+r,h-r),r,.5*math.pi,math.pi),
        7:((-h+r,-h+r),r,math.pi,1.5*math.pi),
    })


def prepare():
    model=prepare_baseline()
    sketches={s['name']:s for s in model['sketches']}
    profile(sketches['Sketch84'],[
        (-1,0),(-1,2),(12,7),(90,10),(105,12),(111,14),(113.2,14),
        (114,14.8),(114,17),(117,17),(117,15),(118,14),
        (139,14),(139.5,13.5),(139.5,0),
    ],{
        6:((113.2,14.8),.8,1.5*math.pi,2*math.pi),
        10:((118,15),1,math.pi,1.5*math.pi),
    })
    rounded_square(sketches['Sketch99'],PEG_W,1)
    rounded_square(sketches['Sketch100'],SOCKET_W,1.2)
    insert = sketches['Sketch56']
    for _, entity in insert['snapshot']['entities']:
        if entity['type'] == 'circle': entity['radius'] = 2.0
    insert['profile_identities'] = {'next':0,'records':[]}
    next(e for e in model['extrudes'] if e['feature_id']==161)['extent']['distance']=6.7
    finish_fastener_cuts(model)
    next(e for e in model['extrudes'] if e['feature_id']==289)['extent']['distance']=10.8
    next(e for e in model['extrudes'] if e['feature_id']==291)['extent']['distance']=SOCKET_DEPTH
    flange=sketches['Sketch101']
    flange['snapshot'].update(entities=[[1,{'type':'circle','center':{'x':0,'y':0},'radius':12}]],
        constraints=[],generated_points=[],fix_targets={},dim_params={},dim_placements={},dim_modes={},
        next_entity=1,next_constraint=0)
    flange['profile_identities']={'next':0,'records':[]};flange['entity_id_high_water']=1
    model['document']['name']='Garden auger - chassis capture and large square drive'
    for definition in model['assembly']['component_structure']['definitions']:
        if definition['id']==14:definition['name']='Large square servo adapter'
    return model


def finish_fastener_cuts(model):
    # Later servo-ear joins otherwise refill the rear-right screw/insert holes.
    # Keep one set of editable cuts, performed after all structural joins.
    names={157:'Upper M3 screw clearance',159:'Upper M3 head seats',161:'Lower ruthex insert pilots'}
    history=model['document']['history']
    cuts=[f for f in history['features'] if f['id'] in names]
    history['features']=[f for f in history['features'] if f['id'] not in names]+cuts
    history['rollback_index']=len(history['features'])
    for feature in cuts: feature['name']=names[feature['id']]
    for e in model['extrudes']:
        if e['feature_id'] in names: e['name']=names[e['feature_id']]


def main():
    (ROOT/'.build').mkdir(exist_ok=True)
    with CadClient() as c:
        if '--export-only' in sys.argv:
            c.call('cad_load_project_model',{'model_json':(ROOT/'.build/model.json').read_text()})
            export(c,json.loads((ROOT/'.build/parts.json').read_text())['sleeve'])
            return
        c.call('cad_load_project_model',{'model_json':json.dumps(prepare())})
        b=Builder(c)
        b.call('solid_move_copy',body_ids=[216],translation={'x':0,'y':.8,'z':0},
            pivot={'x':0,'y':0,'z':0},copy=False)
        seat=[(110.9,0),(110.9,14.4),(112.9,14.4),(113.7,15.2),(113.7,17.2)]
        if USE_RING:
            seat += [(131.2,17.2),(131.2,14.6),(139.8,14.6)]
        else:
            seat += [(117.3,17.2),(117.3,15.4),(118.5,14.2),(139.8,14.2)]
        seat += [(139.8,10.6),(140.1,10.6),(140.1,12.2),(144.3,12.2),(144.3,0)]
        b.revolve('Chassis integral thrust stops and journal seat',seat,'cut',[26,46])
        ring=None
        if USE_RING:
            ring=b.revolve('Plain loose PLA wear sleeve',[
                (117.3,15.5),(118.3,14.2),(130.8,14.2),(131,14.4),
                (131,17),(117.3,17),
            ],'new_body',[])['created_body_id']
            b.call('assembly_create_component',name='Loose PLA wear sleeve - chassis captured',
                body_ids=[ring],absorb_promoted_bodies=True)
        b.revolve('Adapter center screw clearance',[(129.3,0),(129.3,1.7),(143.4,1.7),(143.4,0)],'cut',[216])
        b.revolve('Adapter screw counterbore',[(129.5,0),(129.5,3),(132.1,3),(132.1,0)],'cut',[216])
        b.revolve('Servo interface placeholder - unqualified',[(141.5,0),(141.5,2.85),(143.3,2.85),(143.3,0)],'cut',[216])
        b.call('assembly_update_component',component={'id':8,'body_ids':[90,15],'name':'One-piece auger with integral capture collar'})
        colors={1:((75,98,119),'Purchased servo'),26:((229,174,60),'PETG'),46:((229,174,60),'PETG'),
                90:((213,126,55),'PETG'),15:((213,126,55),'PETG'),216:((190,195,202),'PETG')}
        if ring:colors[ring]=((55,170,161),'PLA - loose wear sleeve')
        for body,(color,material) in colors.items():
            b.call('set_body_appearance',body_id=body,color={**dict(zip(('r','g','b'),color)),'a':255},material_name=material)
        scene=b.call('solid_scene');assert not scene['errors'],scene['errors']
        report=b.call('assembly_interference_check',clearance_threshold_mm=.1)
        assert report['exact']
        assert not any(p['interfering'] for p in report['pairs'] if {p['body_a'],p['body_b']}!={15,90}),report
        parts={'sleeve':ring,'clip':None,'hub_diameter_mm':HUB_D,'square_peg_mm':PEG_W,
               'square_socket_mm':SOCKET_W,'socket_depth_mm':SOCKET_DEPTH,
               'clearance_per_side_mm':.2,
               'heat_set_insert':{'quantity':4,'model':'ruthex RX-M3x5.7','thread':'M3',
                 'outer_diameter_mm':4.6,'length_mm':5.7,'pilot_diameter_mm':4.0,'pilot_depth_mm':6.7,
                 'source':'https://www.igo3d.com/mediafiles/Sonstiges/Ruthex/ruthex_Datenblatt_RX-Serie.pdf'},
               'peg_corner_radius_mm':1,'socket_corner_radius_mm':1.2,'retention':'chassis clamshell only'}
        (ROOT/'.build/parts.json').write_text(json.dumps(parts))
        (ROOT/'.build/scene.json').write_text(json.dumps(scene))
        model=save_project(c,ROOT/'garden-auger-drive.nbcad')
        model,cleanup=clean_checked(c,model,ring)
        (ROOT/'.build/cleanup.json').write_text(json.dumps(cleanup,indent=2))
        model=save_project(c,ROOT/'garden-auger-drive.nbcad')
        (ROOT/'.build/model.json').write_text(json.dumps(model))
        export(c,ring)
        print('Captured drive CAD saved: hub 28, square 14, socket depth 12; no retention hardware',flush=True)


def export(c,ring):
    result=c.call('solid_export_3mf',{'body_ids':[26,46,15,90,216]+([ring] if ring else []),
        'scope':'definition','linear_deflection':.08,'angular_deflection':.2,'slicer_target':'bambu_studio'})
    (ROOT/'.build/raw.3mf').write_bytes(base64.b64decode(result['bytes_base64']))
    preflight=c.call('solid_export_preflight')
    assert preflight['ok'] and not preflight['timeline_errors']
    (ROOT/'.build/preflight.json').write_text(json.dumps(preflight))
    print('Captured native meshes exported',flush=True)


if __name__=='__main__':main()
